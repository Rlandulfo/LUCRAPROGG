import { supabase } from './supabaseClient.js';

document.getElementById('form-cadastro').addEventListener('submit', async (e) => {
    e.preventDefault();

    const nome = document.getElementById('nome').value;
    const email = document.getElementById('email').value;
    const senha = document.getElementById('senha').value;

    const { data, error } = await supabase.auth.signUp({
        email,
        password: senha,
        options: {
            data: { nome: nome }
        }
    });

    if (error) {
        alert('Erro ao cadastrar: ' + error.message);
    } else {
        alert('Cadastro realizado! Verifique seu email para confirmar.');
        window.location.href = 'perfil.html';
    }
});
