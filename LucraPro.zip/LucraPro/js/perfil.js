
// Classe principal do Perfil
class UserProfile {
  constructor() {
    this.initElements();
    this.initEvents();
    this.loadUserData();
    this.setupPasswordStrength();
  }

  // Inicializa elementos da DOM
  initElements() {
    this.elements = {
      // Header
      logoutBtn: document.getElementById('logout-btn'),
      
      // Profile Header
      userName: document.getElementById('user-name'),
      userEmail: document.getElementById('user-email'),
      userPlan: document.getElementById('user-plan'),
      memberSince: document.getElementById('member-since'),
      statCalculations: document.getElementById('stat-calculations'),
      statProducts: document.getElementById('stat-products'),
      statDays: document.getElementById('stat-days'),
      avatarImg: document.getElementById('avatar-img'),
      avatarUpload: document.getElementById('avatar-upload'),
      
      // Tabs
      tabButtons: document.querySelectorAll('.tab-btn'),
      tabContents: document.querySelectorAll('.tab-content'),
      
      // Personal Tab
      profileForm: document.getElementById('profile-form'),
      resetProfileBtn: document.getElementById('reset-profile'),
      
      // Security Tab
      passwordForm: document.getElementById('password-form'),
      togglePasswords: document.querySelectorAll('.toggle-password'),
      passwordStrength: document.getElementById('password-strength'),
      sessionsList: document.getElementById('sessions-list'),
      
      // Subscription Tab
      currentPlanName: document.getElementById('current-plan-name'),
      currentPlanPrice: document.getElementById('current-plan-price'),
      planRenewal: document.getElementById('plan-renewal'),
      changePlanBtn: document.getElementById('change-plan-btn'),
      paymentCards: document.getElementById('payment-cards'),
      addPaymentBtn: document.getElementById('add-payment-btn'),
      
      // Activity Tab
      activityType: document.getElementById('activity-type'),
      activityPeriod: document.getElementById('activity-period'),
      activityList: document.getElementById('activity-list'),
      
      // Modals
      modals: document.querySelectorAll('.modal'),
      modalCloses: document.querySelectorAll('[data-modal-close]'),
      plansModal: document.getElementById('plans-modal'),
      paymentModal: document.getElementById('payment-modal'),
      selectPlans: document.querySelectorAll('.select-plan'),
      newPaymentForm: document.getElementById('new-payment-form')
    };
  }

  // Configura eventos
  initEvents() {
    // Tabs
    this.elements.tabButtons.forEach(btn => {
      btn.addEventListener('click', () => this.switchTab(btn.dataset.tab));
    });

    // Avatar upload
    this.elements.avatarUpload.addEventListener('change', (e) => this.handleAvatarUpload(e));

    // Formulários
    this.elements.profileForm.addEventListener('submit', (e) => this.saveProfile(e));
    this.elements.resetProfileBtn.addEventListener('click', () => this.resetProfileForm());
    this.elements.passwordForm.addEventListener('submit', (e) => this.changePassword(e));

    // Toggle password visibility
    this.elements.togglePasswords.forEach(btn => {
      btn.addEventListener('click', (e) => this.togglePasswordVisibility(e));
    });

    // Logout
    this.elements.logoutBtn.addEventListener('click', () => this.logout());

    // Assinatura
    this.elements.changePlanBtn.addEventListener('click', () => this.openModal('plans-modal'));
    this.elements.addPaymentBtn.addEventListener('click', () => this.openModal('payment-modal'));
    this.elements.selectPlans.forEach(btn => {
      btn.addEventListener('click', () => this.selectPlan(btn.dataset.plan));
    });

    // Modais
    this.elements.modalCloses.forEach(btn => {
      btn.addEventListener('click', () => this.closeModal(btn.closest('.modal')));
    });

    // Filtros de atividade
    this.elements.activityType.addEventListener('change', () => this.filterActivities());
    this.elements.activityPeriod.addEventListener('change', () => this.filterActivities());

    // Novo método de pagamento
    this.elements.newPaymentForm.addEventListener('submit', (e) => this.addPaymentMethod(e));
  }

  // Carrega dados do usuário
  async loadUserData() {
    try {
      // Simulação de requisição à API
      const userData = await this.fetchUserData();
      
      // Preenche os dados do usuário
      this.elements.userName.textContent = userData.name;
      this.elements.userEmail.textContent = userData.email;
      this.elements.userPlan.textContent = this.getPlanName(userData.plan);
      this.elements.memberSince.textContent = `Membro desde ${userData.joinDate}`;
      this.elements.statCalculations.textContent = userData.stats.calculations;
      this.elements.statProducts.textContent = userData.stats.products;
      this.elements.statDays.textContent = userData.stats.activeDays;
      
      // Preenche o formulário de perfil
      document.getElementById('full-name').value = userData.name;
      document.getElementById('business-name').value = userData.business || '';
      document.getElementById('email').value = userData.email;
      document.getElementById('phone').value = userData.phone || '';
      document.getElementById('bio').value = userData.bio || '';
      
      // Carrega sessões ativas
      this.loadSessions(userData.sessions);
      
      // Carrega métodos de pagamento
      this.loadPaymentMethods(userData.paymentMethods);
      
      // Carrega atividades
      this.loadActivities(userData.activities);
      
      // Atualiza informações do plano
      this.updatePlanInfo(userData.plan);
      
    } catch (error) {
      console.error('Erro ao carregar dados do usuário:', error);
      this.showError('Não foi possível carregar os dados do perfil');
    }
  }

  // Simulação de requisição à API
  fetchUserData() {
    return new Promise((resolve) => {
      // Dados mockados - em uma aplicação real, seria uma requisição HTTP
      setTimeout(() => {
        resolve({
          id: 1,
          name: "Dário Martfeld",
          email: "dario.landulfo@exemplo.com",
          business: "Bono Empreendimentos",
          phone: "(71) 98765-4321",
          bio: "Empreendedor no ramo de alimentos há 5 anos, buscando otimizar meus processos com o LucraPro.",
          avatar: "images/avatar-default.jpg",
          plan: "premium",
          joinDate: "15/03/2022",
          stats: {
            calculations: 128,
            products: 42,
            activeDays: 587
          },
          sessions: [
            {
              id: 1,
              device: "Chrome no Windows",
              location: "Salvador, BA",
              ip: "189.45.210.63",
              lastActive: "Hoje, 15:30",
              current: true
            },
            {
              id: 2,
              device: "Safari no iPhone",
              location: "Salvador, BA",
              ip: "189.45.210.64",
              lastActive: "Ontem, 22:15",
              current: false
            }
          ],
          paymentMethods: [
            {
              id: 1,
              type: "credit",
              brand: "visa",
              last4: "4242",
              expiry: "12/25",
              default: true
            },
            {
              id: 2,
              type: "credit",
              brand: "mastercard",
              last4: "5555",
              expiry: "08/24",
              default: false
            }
          ],
          activities: [
            {
              id: 1,
              type: "calculation",
              title: "Cálculo de precificação",
              description: "15 produtos calculados",
              date: "Hoje, 10:30",
              amount: null
            },
            {
              id: 2,
              type: "payment",
              title: "Pagamento mensal",
              description: "Plano Premium",
              date: "15/09/2023",
              amount: "R$ 99,90"
            },
            {
              id: 3,
              type: "login",
              title: "Login realizado",
              description: "Dispositivo novo",
              date: "14/09/2023",
              amount: null
            }
          ]
        });
      }, 500);
    });
  }

  // Alterna entre abas
  switchTab(tabId) {
    // Remove classe active de todas as abas e botões
    this.elements.tabButtons.forEach(btn => {
      btn.classList.remove('active');
      btn.setAttribute('aria-selected', 'false');
    });
    
    this.elements.tabContents.forEach(content => {
      content.classList.remove('active');
      content.setAttribute('aria-hidden', 'true');
    });
    
    // Adiciona classe active na aba selecionada
    const activeBtn = document.querySelector(`.tab-btn[data-tab="${tabId}"]`);
    const activeContent = document.getElementById(`${tabId}-tab`);
    
    activeBtn.classList.add('active');
    activeBtn.setAttribute('aria-selected', 'true');
    activeContent.classList.add('active');
    activeContent.setAttribute('aria-hidden', 'false');
  }

  // Manipula upload de avatar
  handleAvatarUpload(event) {
    const file = event.target.files[0];
    if (!file) return;

    if (!file.type.match('image.*')) {
      this.showError('Por favor, selecione uma imagem válida');
      return;
    }

    if (file.size > 2 * 1024 * 1024) {
      this.showError('A imagem deve ter menos de 2MB');
      return;
    }

    const reader = new FileReader();
    reader.onload = (e) => {
      this.elements.avatarImg.src = e.target.result;
      // Aqui você enviaria a imagem para o servidor em uma aplicação real
      this.showSuccess('Foto de perfil atualizada com sucesso!');
    };
    reader.readAsDataURL(file);
  }

  // Salva informações do perfil
  async saveProfile(event) {
    event.preventDefault();
    
    const formData = {
      name: document.getElementById('full-name').value.trim(),
      business: document.getElementById('business-name').value.trim(),
      email: document.getElementById('email').value.trim(),
      phone: document.getElementById('phone').value.trim(),
      bio: document.getElementById('bio').value.trim()
    };

    // Validações básicas
    if (!formData.name || !formData.email) {
      this.showError('Nome e e-mail são obrigatórios');
      return;
    }

    try {
      // Simulação de requisição à API
      await this.updateProfile(formData);
      
      // Atualiza a exibição
      this.elements.userName.textContent = formData.name;
      this.elements.userEmail.textContent = formData.email;
      
      this.showSuccess('Perfil atualizado com sucesso!');
    } catch (error) {
      console.error('Erro ao atualizar perfil:', error);
      this.showError('Não foi possível atualizar o perfil');
    }
  }

  // Simulação de atualização de perfil
  updateProfile(data) {
    return new Promise((resolve) => {
      setTimeout(() => {
        resolve(data);
      }, 800);
    });
  }

  // Reseta o formulário de perfil
  resetProfileForm() {
    this.elements.profileForm.reset();
    this.loadUserData(); // Recarrega os dados originais
  }

  // Configura a força da senha
  setupPasswordStrength() {
    const passwordInput = document.getElementById('new-password');
    const strengthBar = this.elements.passwordStrength.querySelector('.strength-bar');
    const strengthText = this.elements.passwordStrength.querySelector('.strength-text');
  
    passwordInput.addEventListener('input', () => {
      const password = passwordInput.value;
      const strength = this.calculatePasswordStrength(password);
  
      strengthBar.classList.remove('strength-weak', 'strength-medium', 'strength-strong');
      strengthBar.style.width = `${strength.score * 25}%`;
      
      if (strength.score < 2) {
        strengthBar.classList.add('strength-weak');
        strengthText.textContent = 'Fraca';
      } else if (strength.score < 4) {
        strengthBar.classList.add('strength-medium');
        strengthText.textContent = 'Média';
      } else {
        strengthBar.classList.add('strength-strong');
        strengthText.textContent = 'Forte';
      }
    });
  }

  // Calcula a força da senha
  calculatePasswordStrength(password) {
    let score = 0;
    
    // Critérios de força
    if (password.length >= 8) score++;
    if (password.length >= 12) score++;
    if (/[A-Z]/.test(password)) score++;
    if (/[0-9]/.test(password)) score++;
    if (/[^A-Za-z0-9]/.test(password)) score++;
    
    return { score };
  }

  // Alterna visibilidade da senha
  togglePasswordVisibility(event) {
    const button = event.currentTarget;
    const input = button.previousElementSibling;
    const icon = button.querySelector('i');
    
    if (input.type === 'password') {
      input.type = 'text';
      icon.classList.replace('fa-eye', 'fa-eye-slash');
      button.setAttribute('aria-label', 'Ocultar senha');
    } else {
      input.type = 'password';
      icon.classList.replace('fa-eye-slash', 'fa-eye');
      button.setAttribute('aria-label', 'Mostrar senha');
    }
  }

  // Altera a senha do usuário
  async changePassword(event) {
    event.preventDefault();
    
    const currentPassword = document.getElementById('current-password').value;
    const newPassword = document.getElementById('new-password').value;
    const confirmPassword = document.getElementById('confirm-password').value;

    // Validações
    if (!currentPassword || !newPassword || !confirmPassword) {
      this.showError('Todos os campos são obrigatórios');
      return;
    }

    if (newPassword.length < 8) {
      this.showError('A senha deve ter pelo menos 8 caracteres');
      return;
    }

    if (newPassword !== confirmPassword) {
      this.showError('As senhas não coincidem');
      return;
    }

    try {
      // Simulação de requisição à API
      await this.updatePassword(currentPassword, newPassword);
      
      // Limpa o formulário
      this.elements.passwordForm.reset();
      
      this.showSuccess('Senha alterada com sucesso!');
    } catch (error) {
      console.error('Erro ao alterar senha:', error);
      this.showError('Não foi possível alterar a senha. Verifique sua senha atual.');
    }
  }

  // Simulação de atualização de senha
  updatePassword(currentPassword, newPassword) {
    return new Promise((resolve, reject) => {
      setTimeout(() => {
        // Simulação de erro se a senha atual for "errada"
        if (currentPassword === 'errada') {
          reject(new Error('Senha atual incorreta'));
        } else {
          resolve();
        }
      }, 800);
    });
  }

  // Carrega sessões ativas
  loadSessions(sessions) {
    this.elements.sessionsList.innerHTML = '';
    
    sessions.forEach(session => {
      const sessionItem = document.createElement('div');
      sessionItem.className = 'session-item';
      
      sessionItem.innerHTML = `
        <div class="session-info">
          <div class="session-device">
            ${session.device}
            ${session.current ? '<span class="session-current">(Atual)</span>' : ''}
          </div>
          <div class="session-details">
            ${session.location} • ${session.ip} • Último acesso: ${session.lastActive}
          </div>
        </div>
        ${!session.current ? `
        <div class="session-actions">
          <button data-id="${session.id}" class="btn-logout-session">Encerrar</button>
        </div>
        ` : ''}
      `;
      
      this.elements.sessionsList.appendChild(sessionItem);
    });

    // Adiciona listeners para os botões de encerrar sessão
    document.querySelectorAll('.btn-logout-session').forEach(btn => {
      btn.addEventListener('click', () => {
        const sessionId = parseInt(btn.dataset.id);
        this.endSession(sessionId);
      });
    });
  }

  // Encerra uma sessão
  async endSession(sessionId) {
    if (!confirm('Tem certeza que deseja encerrar esta sessão?')) return;
    
    try {
      // Simulação de requisição à API
      await this.logoutSession(sessionId);
      
      // Recarrega as sessões
      const userData = await this.fetchUserData();
      this.loadSessions(userData.sessions);
      
      this.showSuccess('Sessão encerrada com sucesso');
    } catch (error) {
      console.error('Erro ao encerrar sessão:', error);
      this.showError('Não foi possível encerrar a sessão');
    }
  }

  // Simulação de logout de sessão
  logoutSession(sessionId) {
    return new Promise((resolve) => {
      setTimeout(() => {
        resolve();
      }, 500);
    });
  }

  // Atualiza informações do plano
  updatePlanInfo(plan) {
    const plans = {
      basic: {
        name: 'Plano Básico',
        price: 'R$49,90/mês',
        renewal: 'Próxima cobrança: 15/10/2023'
      },
      premium: {
        name: 'Plano Premium',
        price: 'R$99,90/mês',
        renewal: 'Próxima cobrança: 15/10/2023'
      },
      enterprise: {
        name: 'Plano Empresarial',
        price: 'R$199,90/mês',
        renewal: 'Próxima cobrança: 15/10/2023'
      }
    };
    
    const selectedPlan = plans[plan] || plans.premium;
    
    this.elements.currentPlanName.textContent = selectedPlan.name;
    this.elements.currentPlanPrice.textContent = selectedPlan.price;
    this.elements.planRenewal.textContent = selectedPlan.renewal;
  }

  // Carrega métodos de pagamento
  loadPaymentMethods(payments) {
    this.elements.paymentCards.innerHTML = '';
    
    payments.forEach(payment => {
      const paymentCard = document.createElement('div');
      paymentCard.className = `payment-card ${payment.default ? 'payment-card-default' : ''}`;
      
      const brandIcon = this.getPaymentBrandIcon(payment.brand);
      
      paymentCard.innerHTML = `
        <div class="payment-card-icon">${brandIcon}</div>
        <div class="payment-card-info">
          <div class="payment-card-type">
            Cartão de crédito
            ${payment.default ? '<span class="payment-card-default-badge">Padrão</span>' : ''}
          </div>
          <div class="payment-card-number">•••• •••• •••• ${payment.last4}</div>
          <div class="payment-card-expiry">Expira em ${payment.expiry}</div>
        </div>
        <div class="payment-card-actions">
          ${!payment.default ? '<button class="btn-set-default" data-id="' + payment.id + '"><i class="fas fa-star"></i></button>' : ''}
          <button class="btn-remove-payment" data-id="${payment.id}"><i class="fas fa-trash"></i></button>
        </div>
      `;
      
      this.elements.paymentCards.appendChild(paymentCard);
    });

    // Adiciona listeners para os botões de pagamento
    document.querySelectorAll('.btn-set-default').forEach(btn => {
      btn.addEventListener('click', () => {
        const paymentId = parseInt(btn.dataset.id);
        this.setDefaultPaymentMethod(paymentId);
      });
    });

    document.querySelectorAll('.btn-remove-payment').forEach(btn => {
      btn.addEventListener('click', () => {
        const paymentId = parseInt(btn.dataset.id);
        this.removePaymentMethod(paymentId);
      });
    });
  }

  // Retorna o ícone da bandeira do cartão
  getPaymentBrandIcon(brand) {
    const icons = {
      visa: '<i class="fab fa-cc-visa"></i>',
      mastercard: '<i class="fab fa-cc-mastercard"></i>',
      amex: '<i class="fab fa-cc-amex"></i>',
      discover: '<i class="fab fa-cc-discover"></i>',
      diners: '<i class="fab fa-cc-diners-club"></i>',
      jcb: '<i class="fab fa-cc-jcb"></i>'
    };
    return icons[brand.toLowerCase()] || '<i class="far fa-credit-card"></i>';
  }

  // Define um método de pagamento como padrão
  async setDefaultPaymentMethod(paymentId) {
    try {
      // Simulação de requisição à API
      await this.updateDefaultPayment(paymentId);
      
      // Recarrega os métodos de pagamento
      const userData = await this.fetchUserData();
      this.loadPaymentMethods(userData.paymentMethods);
      
      this.showSuccess('Método de pagamento definido como padrão');
    } catch (error) {
      console.error('Erro ao definir método padrão:', error);
      this.showError('Não foi possível definir o método padrão');
    }
  }

  // Simulação de atualização de método padrão
  updateDefaultPayment(paymentId) {
    return new Promise((resolve) => {
      setTimeout(() => {
        resolve();
      }, 500);
    });
  }

  // Remove um método de pagamento
  async removePaymentMethod(paymentId) {
    if (!confirm('Tem certeza que deseja remover este método de pagamento?')) return;
    
    try {
      // Simulação de requisição à API
      await this.deletePaymentMethod(paymentId);
      
      // Recarrega os métodos de pagamento
      const userData = await this.fetchUserData();
      this.loadPaymentMethods(userData.paymentMethods);
      
      this.showSuccess('Método de pagamento removido com sucesso');
    } catch (error) {
      console.error('Erro ao remover método de pagamento:', error);
      this.showError('Não foi possível remover o método de pagamento');
    }
  }

  // Simulação de remoção de método de pagamento
  deletePaymentMethod(paymentId) {
    return new Promise((resolve) => {
      setTimeout(() => {
        resolve();
      }, 500);
    });
  }

  // Adiciona um novo método de pagamento
  async addPaymentMethod(event) {
    event.preventDefault();
    
    const cardNumber = document.getElementById('card-number').value.replace(/\s/g, '');
    const cardExpiry = document.getElementById('card-expiry').value;
    const cardCvv = document.getElementById('card-cvv').value;
    const cardName = document.getElementById('card-name').value;
    const isDefault = document.getElementById('default-payment').checked;

    // Validações básicas
    if (!cardNumber || !cardExpiry || !cardCvv || !cardName) {
      this.showError('Todos os campos são obrigatórios');
      return;
    }

    if (!/^\d{13,16}$/.test(cardNumber)) {
      this.showError('Número do cartão inválido');
      return;
    }

    if (!/^\d{3,4}$/.test(cardCvv)) {
      this.showError('CVV inválido');
      return;
    }

    try {
      // Simulação de requisição à API
      await this.saveNewPaymentMethod({
        cardNumber,
        cardExpiry,
        cardCvv,
        cardName,
        isDefault
      });
      
      // Fecha o modal e limpa o formulário
      this.closeModal(this.elements.paymentModal);
      this.elements.newPaymentForm.reset();
      
      // Recarrega os métodos de pagamento
      const userData = await this.fetchUserData();
      this.loadPaymentMethods(userData.paymentMethods);
      
      this.showSuccess('Método de pagamento adicionado com sucesso!');
    } catch (error) {
      console.error('Erro ao adicionar método de pagamento:', error);
      this.showError('Não foi possível adicionar o método de pagamento');
    }
  }

  // Simulação de salvamento de novo método de pagamento
  saveNewPaymentMethod(data) {
    return new Promise((resolve) => {
      setTimeout(() => {
        resolve(data);
      }, 800);
    });
  }

  // Carrega atividades do usuário
  loadActivities(activities, filterType = 'all', filterPeriod = '30') {
    this.elements.activityList.innerHTML = '';
    
    // Filtra as atividades (simulação)
    let filteredActivities = activities.filter(activity => {
      if (filterType !== 'all' && activity.type !== filterType) return false;
      // Aqui seria implementada a filtragem por período em uma aplicação real
      return true;
    });
    
    filteredActivities.forEach(activity => {
      const activityItem = document.createElement('div');
      activityItem.className = 'activity-item';
      
      const activityIcon = this.getActivityIcon(activity.type);
      
      activityItem.innerHTML = `
        <div class="activity-icon">${activityIcon}</div>
        <div class="activity-content">
          <div class="activity-title">${activity.title}</div>
          <div class="activity-description">${activity.description}</div>
        </div>
        <div class="activity-meta">
          ${activity.amount ? `<div class="activity-amount">${activity.amount}</div>` : ''}
          <div class="activity-date">${activity.date}</div>
        </div>
      `;
      
      this.elements.activityList.appendChild(activityItem);
    });
  }

  // Retorna o ícone do tipo de atividade
  getActivityIcon(type) {
    const icons = {
      calculation: '<i class="fas fa-calculator"></i>',
      payment: '<i class="fas fa-credit-card"></i>',
      login: '<i class="fas fa-sign-in-alt"></i>'
    };
    return icons[type] || '<i class="fas fa-history"></i>';
  }

  // Filtra atividades
  filterActivities() {
    const type = this.elements.activityType.value;
    const period = this.elements.activityPeriod.value;
    
    // Em uma aplicação real, faria uma nova requisição à API
    // Aqui apenas simulamos com os dados já carregados
    this.loadUserData(); // Recarrega os dados para simular o filtro
  }

  // Seleciona um novo plano
  async selectPlan(plan) {
    if (!confirm(`Tem certeza que deseja mudar para o ${this.getPlanName(plan)}?`)) return;
    
    try {
      // Simulação de requisição à API
      await this.updateUserPlan(plan);
      
      // Atualiza a exibição
      this.updatePlanInfo(plan);
      this.closeModal(this.elements.plansModal);
      
      this.showSuccess(`Plano alterado para ${this.getPlanName(plan)} com sucesso!`);
    } catch (error) {
      console.error('Erro ao alterar plano:', error);
      this.showError('Não foi possível alterar o plano');
    }
  }

  // Retorna o nome do plano
  getPlanName(planKey) {
    const plans = {
      basic: 'Plano Básico',
      premium: 'Plano Premium',
      enterprise: 'Plano Empresarial'
    };
    return plans[planKey] || 'Plano Desconhecido';
  }

  // Simulação de atualização de plano
  updateUserPlan(plan) {
    return new Promise((resolve) => {
      setTimeout(() => {
        resolve(plan);
      }, 800);
    });
  }

  // Faz logout do usuário
  logout() {
    if (confirm('Tem certeza que deseja sair?')) {
      // Simulação de logout
      // Em uma aplicação real, limparia tokens e redirecionaria
      window.location.href = 'login.html';
    }
  }

  // Abre um modal
  openModal(modalId) {
    const modal = document.getElementById(modalId);
    modal.classList.add('active');
    document.body.style.overflow = 'hidden';
  }

  // Fecha um modal
  closeModal(modal) {
    modal.classList.remove('active');
    document.body.style.overflow = '';
  }

  // Mostra mensagem de sucesso
  showSuccess(message) {
    // Em uma aplicação real, usaria um sistema de notificações mais sofisticado
    alert(message);
  }

  // Mostra mensagem de erro
  showError(message) {
    // Em uma aplicação real, usaria um sistema de notificações mais sofisticado
    alert(message);
  }
}

document.getElementById('logout').addEventListener('click', async () => {
  await supabase.auth.signOut();
  window.location.href = 'login.html';
});


// Inicializa a aplicação quando o DOM estiver pronto
document.addEventListener('DOMContentLoaded', () => {
  new UserProfile();
});