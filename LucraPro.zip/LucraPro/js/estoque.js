const produtos = {
    "Brigadeiro Gourmet": {
      estoque: 150,
      preco: 4.50,
      quantidadeVendida: 100,
      custoUnitario: 2.75
    },
    "Bolo de Chocolate": {
      estoque: 20,
      preco: 45.00,
      quantidadeVendida: 10,
      custoUnitario: 28.40
    },
    "Cupcake": {
      estoque: 50,
      preco: 5.90,
      quantidadeVendida: 80,
      custoUnitario: 3.20
    }
  };
  
  let produtoSelecionado = null;
  let grafico = null;
  
  function atualizarInfo(produto) {
    const info = produtos[produto];
    const pontoEquilibrio = Math.ceil(info.custoUnitario / (info.preco - info.custoUnitario));
    const retornoBruto = info.preco * info.quantidadeVendida;
  
    document.getElementById('estoque-atual').textContent = info.estoque;
    document.getElementById('preco-produto').textContent = `R$ ${info.preco.toFixed(2)}`;
    document.getElementById('ponto-equilibrio').textContent = `${pontoEquilibrio} unidades`;
    document.getElementById('quantidade-vendida').textContent = info.quantidadeVendida;
    document.getElementById('retorno-bruto').textContent = `R$ ${retornoBruto.toFixed(2)}`;
  
    document.getElementById('estoque-info').style.display = 'block';
    
    atualizarGrafico(info);
  }
  
  document.getElementById('produto-estoque').addEventListener('change', function() {
    produtoSelecionado = this.value;
    atualizarInfo(produtoSelecionado);
  });
  
  // Atualizar Estoque
  document.getElementById('btn-atualizar-estoque').addEventListener('click', function() {
    const novoEstoque = prompt("Digite o novo estoque para o produto:");
    if (novoEstoque !== null) {
      const estoqueNum = parseInt(novoEstoque);
      if (!isNaN(estoqueNum)) {
        produtos[produtoSelecionado].estoque = estoqueNum;
        atualizarInfo(produtoSelecionado);
        alert("Estoque atualizado com sucesso!");
      } else {
        alert("Por favor, insira um número válido.");
      }
    }
  });
  
  // Registrar Reposição
  document.getElementById('btn-registrar-reposicao').addEventListener('click', function() {
    const reposicao = prompt("Digite a quantidade para repor no estoque:");
    if (reposicao !== null) {
      const reposicaoNum = parseInt(reposicao);
      if (!isNaN(reposicaoNum)) {
        produtos[produtoSelecionado].estoque += reposicaoNum;
        atualizarInfo(produtoSelecionado);
        alert("Reposição registrada com sucesso!");
      } else {
        alert("Por favor, insira um número válido.");
      }
    }
  });

  // Registrar Baixa
document.getElementById('btn-registrar-baixa').addEventListener('click', function() {
  const baixa = prompt("Digite a quantidade a dar baixa no estoque:");
  if (baixa !== null) {
    const baixaNum = parseInt(baixa);
    if (!isNaN(baixaNum)) {
      if (produtos[produtoSelecionado].estoque >= baixaNum) {
        produtos[produtoSelecionado].estoque -= baixaNum;
        atualizarInfo(produtoSelecionado);
        alert("Baixa registrada com sucesso!");
      } else {
        alert("Erro: a quantidade de baixa excede o estoque atual.");
      }
    } else {
      alert("Por favor, insira um número válido.");
    }
  }
});

  
  // Gráfico
  function atualizarGrafico(info) {
    const ctx = document.getElementById('grafico-estoque').getContext('2d');
    
    if (grafico) {
      grafico.destroy();
    }
    
    grafico = new Chart(ctx, {
      type: 'bar',
      data: {
        labels: ['Estoque Atual', 'Quantidade Vendida'],
        datasets: [{
          label: 'Unidades',
          data: [info.estoque, info.quantidadeVendida],
          backgroundColor: ['#4CAF50', '#FF9800']
        }]
      },
      options: {
        responsive: true,
        scales: {
          y: {
            beginAtZero: true,
            precision: 0
          }
        }
      }
    });
  }
  