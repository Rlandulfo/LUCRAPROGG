
import { createClient } from 'https://cdn.jsdelivr.net/npm/@supabase/supabase-js/+esm';

const SUPABASE_URL = 'https://ygowfhgytljosfjcjnud.supabase.co';
const SUPABASE_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Inlnb3dmaGd5dGxqb3NmamNqbnVkIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDg3MDY4MDMsImV4cCI6MjA2NDI4MjgwM30.KA82uRfKzJS6y6X_lDjEef3IzmhubTGOsrp1QWEgaAk';

const supabase = createClient(SUPABASE_URL, SUPABASE_KEY);

console.log('Supabase conectado:', supabase);


document.addEventListener('DOMContentLoaded', function() {
  
  if (localStorage.getItem('loggedIn') === 'true') {
    document.getElementById('login-btn').style.display = 'none';
    document.getElementById('register-btn').style.display = 'none';
    document.getElementById('profile-btn').style.display = 'inline-flex';
    document.getElementById('logout-btn').style.display = 'inline-flex';
  }
    
  // Funções para manipulação dos modais
  function openModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
      modal.classList.add('active');
      document.body.style.overflow = 'hidden';
    }
  }

  function closeModal(modalId) {
    const modal = typeof modalId === 'string' ? document.getElementById(modalId) : modalId;
    if (modal) {
      modal.classList.remove('active');
      document.body.style.overflow = 'auto';
    }
  }

  const logoutBtn = document.getElementById('logout-btn');
if (logoutBtn) {
  logoutBtn.addEventListener('click', async function(e) {
    e.preventDefault();
    await supabase.auth.signOut();
    localStorage.removeItem('loggedIn');
    
    document.getElementById('login-btn').style.display = 'inline-flex';
    document.getElementById('register-btn').style.display = 'inline-flex';
    document.getElementById('profile-btn').style.display = 'none';
    document.getElementById('logout-btn').style.display = 'none';
    
    alert('Você saiu com sucesso!');
  });
}


  // Verificação de sessão
  (async () => {
    try {
      const { data, error } = await supabase.auth.getSession();

      if (!data.session) {
        console.log('Usuário não autenticado');
      }
    } catch (err) {
      console.error('Erro ao verificar sessão:', err);
    }
  })();

  // Event listeners para os botões de login e registro
  const loginBtn = document.getElementById('login-btn');
  const registerBtn = document.getElementById('register-btn');
  const loginModal = document.getElementById('login-modal');
  const registerModal = document.getElementById('register-modal');
  const showRegister = document.getElementById('show-register');
  const showLogin = document.getElementById('show-login');
  const modalCloses = document.querySelectorAll('.modal-close');

  // Abrir modal de login
  if (loginBtn && loginModal) {
    loginBtn.addEventListener('click', (e) => {
      e.preventDefault();
      openModal('login-modal');
    });
  }

  // Abrir modal de registro
  if (registerBtn && registerModal) {
    registerBtn.addEventListener('click', (e) => {
      e.preventDefault();
      openModal('register-modal');
    });
  }

  // Alternar entre login e registro
  if (showRegister && registerModal && loginModal) {
    showRegister.addEventListener('click', (e) => {
      e.preventDefault();
      closeModal(loginModal);
      openModal('register-modal');
    });
  }

  if (showLogin && loginModal && registerModal) {
    showLogin.addEventListener('click', (e) => {
      e.preventDefault();
      closeModal(registerModal);
      openModal('login-modal');
    });
  }

  // Fechar modais
  modalCloses.forEach(closeBtn => {
    closeBtn.addEventListener('click', () => {
      const modal = closeBtn.closest('.modal');
      closeModal(modal);
    });
  });

  // Fechar modal ao clicar fora
  window.addEventListener('click', (e) => {
    if (e.target.classList.contains('modal')) {
      closeModal(e.target);
    }
  });

  // Fechar com o ESC
  window.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
      document.querySelectorAll('.modal.active').forEach(modal => closeModal(modal));
    }
  });

 // Formulário de Registro
const registerForm = document.getElementById('register-form');
if (registerForm) {
  registerForm.addEventListener('submit', async (e) => {
    e.preventDefault();

    const email = registerForm.querySelector('input[type="email"]')?.value;
    const senha = registerForm.querySelector('input[type="password"]')?.value;
    const nome = registerForm.querySelector('input[type="text"]')?.value;
    const businessName = registerForm.querySelector('#business-name')?.value;
    const telefone = registerForm.querySelector('#user-phone')?.value;

    if (!email || !senha || !nome || !telefone) {
      alert('Preencha todos os campos!');
      return;
    }

    try {
      const { data, error } = await supabase.auth.signUp({
        email: email,
        password: senha,
        options: {
          data: {
            nome: nome,
            negocio: businessName,
            telefone: telefone
          }
        }
      });

      if (error) {
        alert('Erro ao registrar: ' + error.message);
      } else {
        // Inserir os dados na tabela usuarios
        const user = data.user;
        if (user) {
          const { error: insertError } = await supabase.from('usuarios').insert([{
            id: user.id,
            nome: nome,
            email: email,
            negocio: businessName,
            telefone: telefone
          }]);

          if (insertError) {
            console.error('Erro ao salvar na tabela usuarios:', insertError);
          }
        }

        alert('Cadastro realizado! Agora faça login para continuar.');
        closeModal(registerModal);
        openModal('login-modal');
      }
    } catch (err) {
      console.error(err);
      alert('Erro inesperado');
    }
  });
}


  // Formulário de Login
  const loginForm = document.getElementById('login-form');
  if (loginForm) {
    loginForm.addEventListener('submit', async (e) => {
      e.preventDefault();

      const email = loginForm.querySelector('input[type="email"]')?.value;
      const senha = loginForm.querySelector('input[type="password"]')?.value;

      if (!email || !senha) {
        alert('Preencha todos os campos!');
        return;
      }

      try {
        const { data, error } = await supabase.auth.signInWithPassword({
          email: email,
          password: senha,
        });

        if (error) {
          alert('Erro ao logar: ' + error.message);
        } else {
          alert('Login bem-sucedido!');
closeModal(loginModal);
localStorage.setItem('loggedIn', 'true');

document.getElementById('login-btn').style.display = 'none';
document.getElementById('register-btn').style.display = 'none';
document.getElementById('profile-btn').style.display = 'inline-flex';
document.getElementById('logout-btn').style.display = 'inline-flex';

        }
      } catch (err) {
        console.error(err);
        alert('Erro inesperado');
      }
    });
  }

  // Menu Mobile
  const mobileMenuBtn = document.querySelector('.mobile-menu-btn');
  const navList = document.querySelector('.nav-list');
  
  if (mobileMenuBtn && navList) {
    mobileMenuBtn.addEventListener('click', function() {
      const isExpanded = this.getAttribute('aria-expanded') === 'true';
      this.setAttribute('aria-expanded', !isExpanded);
      navList.classList.toggle('active');
      document.body.style.overflow = isExpanded ? 'auto' : 'hidden';
    });
  }
  
  // Fechar menu ao clicar em um link
  const navLinks = document.querySelectorAll('.nav-link');
  if (navLinks.length > 0 && navList && mobileMenuBtn) {
    navLinks.forEach(link => {
      link.addEventListener('click', function() {
        navList.classList.remove('active');
        mobileMenuBtn.setAttribute('aria-expanded', 'false');
        document.body.style.overflow = 'auto';
      });
    });
  }
  
  // Scroll suave para seções
  const scrollLinks = document.querySelectorAll('a[href^="#"]');
  if (scrollLinks.length > 0) {
    scrollLinks.forEach(anchor => {
      anchor.addEventListener('click', function(e) {
        e.preventDefault();
        
        const targetId = this.getAttribute('href');
        if (targetId === '#') return;
        
        const targetElement = document.querySelector(targetId);
        const header = document.querySelector('.header');
        
        if (targetElement && header) {
          const headerHeight = header.offsetHeight;
          const targetPosition = targetElement.getBoundingClientRect().top + window.pageYOffset - headerHeight;
          
          window.scrollTo({
            top: targetPosition,
            behavior: 'smooth'
          });
        }
      });
    });
  }
  
  // Ativar link ativo na navegação
  window.addEventListener('scroll', function() {
    const header = document.querySelector('.header');
    const sections = document.querySelectorAll('section');
    const navLinks = document.querySelectorAll('.nav-link');
    
    if (header && sections.length > 0 && navLinks.length > 0) {
      const scrollPosition = window.scrollY;
      const headerHeight = header.offsetHeight;
      
      sections.forEach(section => {
        const sectionTop = section.offsetTop - headerHeight - 50;
        const sectionHeight = section.offsetHeight;
        const sectionId = section.getAttribute('id');
        
        if (scrollPosition >= sectionTop && scrollPosition < sectionTop + sectionHeight) {
          navLinks.forEach(link => {
            link.classList.remove('active');
            if (link.getAttribute('href') === `#${sectionId}`) {
              link.classList.add('active');
            }
          });
        }
      });
    }
  });
  
  // Efeito de scroll no header
  window.addEventListener('scroll', function() {
    const header = document.querySelector('.header');
    if (header) {
      if (window.scrollY > 100) {
        header.style.boxShadow = '0 2px 10px rgba(0, 0, 0, 0.5)';
      } else {
        header.style.boxShadow = 'none';
      }
    }
  });
  
  // Contador animado
  const statNumbers = document.querySelectorAll('.stat-number');
  
  if (statNumbers.length > 0) {
    const observer = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          startCounter(entry.target);
          observer.unobserve(entry.target);
        }
      });
    }, { threshold: 0.5 });
    
    statNumbers.forEach(number => {
      observer.observe(number);
    });
    
    function startCounter(element) {
      const target = parseInt(element.getAttribute('data-count'));
      const duration = 2000; // ms
      const step = target / (duration / 16); // 60fps
      let current = 0;
      
      const counter = setInterval(() => {
        current += step;
        if (current >= target) {
          clearInterval(counter);
          element.textContent = target;
        } else {
          element.textContent = Math.floor(current);
        }
      }, 16);
    }
  }
  
  // Slider de depoimentos
  const testimonialCards = document.querySelectorAll('.testimonial-card');
  const prevBtn = document.querySelector('.slider-prev');
  const nextBtn = document.querySelector('.slider-next');
  
  if (testimonialCards.length > 0 && prevBtn && nextBtn) {
    let currentIndex = 0;
    showTestimonial(currentIndex);
    
    nextBtn.addEventListener('click', () => {
      currentIndex = (currentIndex + 1) % testimonialCards.length;
      showTestimonial(currentIndex);
    });
    
    prevBtn.addEventListener('click', () => {
      currentIndex = (currentIndex - 1 + testimonialCards.length) % testimonialCards.length;
      showTestimonial(currentIndex);
    });
    
    function showTestimonial(index) {
      testimonialCards.forEach((card, i) => {
        card.classList.remove('active');
        if (i === index) {
          card.classList.add('active');
        }
      });
    }
  }
  

  
  // Fechar modal ao clicar fora
  window.addEventListener('click', (e) => {
    if (e.target.classList.contains('modal')) {
      closeModal(e.target);
    }
  });
  
  // Validação de formulários
  const forms = document.querySelectorAll('form');
  
  if (forms.length > 0) {
    forms.forEach(form => {
      form.addEventListener('submit', function(e) {
        e.preventDefault();
        
        const formName = this.getAttribute('id') || 'form';
        const submitBtn = this.querySelector('button[type="submit"]');
        
        if (submitBtn) {
          const originalText = submitBtn.textContent;
          
          submitBtn.disabled = true;
          submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Enviando...';
          
          // Simular atraso de rede
          setTimeout(() => {
            submitBtn.innerHTML = '<i class="fas fa-check"></i> Enviado!';
            
            setTimeout(() => {
              submitBtn.disabled = false;
              submitBtn.textContent = originalText;
              
              // Mostrar mensagem de sucesso
              if (formName === 'contact-form' || formName === 'newsletter-form') {
                alert('Obrigado por entrar em contato! Responderemos em breve.');
                this.reset();
              } else if (formName === 'hero-form' || formName === 'cta-form') {
                alert('Obrigado pelo seu interesse! Em breve enviaremos mais informações.');
                this.reset();
              }
            }, 1000);
          }, 1500);
        }
      });
    });
  }
  
  // Carregamento lazy de imagens
  if ('IntersectionObserver' in window) {
    const lazyImages = document.querySelectorAll('img[loading="lazy"]');
    
    if (lazyImages.length > 0) {
      const imageObserver = new IntersectionObserver((entries, observer) => {
        entries.forEach(entry => {
          if (entry.isIntersecting) {
            const img = entry.target;
            img.src = img.getAttribute('src');
            img.removeAttribute('loading');
            observer.unobserve(img);
          }
        });
      });
      
      lazyImages.forEach(img => {
        imageObserver.observe(img);
      });
    }
  }
  
  // Animação ao rolar
  const animateOnScroll = function() {
    const elements = document.querySelectorAll('.feature-card, .benefit-card, .pricing-card');
    
    if (elements.length > 0) {
      const windowHeight = window.innerHeight;
      
      elements.forEach(element => {
        const elementPosition = element.getBoundingClientRect().top;
        const animationPoint = 150;
        
        if (elementPosition < windowHeight - animationPoint) {
          element.style.opacity = '1';
          element.style.transform = 'translateY(0)';
        }
      });
    }
  };
  
  // Configurar animações iniciais
  const animatedElements = document.querySelectorAll('.feature-card, .benefit-card, .pricing-card');
  
  if (animatedElements.length > 0) {
    animatedElements.forEach(element => {
      element.style.opacity = '0';
      element.style.transform = 'translateY(20px)';
      element.style.transition = 'opacity 0.5s ease, transform 0.5s ease';
    });
    
    window.addEventListener('scroll', animateOnScroll);
    animateOnScroll(); // Verificar elementos visíveis no carregamento
  }
 
  // Fechar com o ESC
  window.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
      document.querySelectorAll('.modal.active').forEach(modal => closeModal(modal));
    }
  });
});