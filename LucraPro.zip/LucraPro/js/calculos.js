document.addEventListener('DOMContentLoaded', function() {
  // Inicializa o Supabase
  const supabaseUrl = 'https://ygowfhgytljosfjcjnud.supabase.co';
  const supabaseKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Inlnb3dmaGd5dGxqb3NmamNqbnVkIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDg3MDY4MDMsImV4cCI6MjA2NDI4MjgwM30.KA82uRfKzJS6y6X_lDjEef3IzmhubTGOsrp1QWEgaAk';
  const supabase = window.supabase.createClient(supabaseUrl, supabaseKey);

  // Elementos do formulário
  const form = document.getElementById('form-calculadora');
  const nomeProduto = document.getElementById('nome-produto');
  const quantidade = document.getElementById('quantidade');
  const custoMaterial = document.getElementById('custo-material');
  const maoObra = document.getElementById('mao-obra');
  const despesasGerais = document.getElementById('despesas-gerais');
  const impostos = document.getElementById('impostos');
  const margemRange = document.getElementById('margem-range');
  const margemValue = document.getElementById('margem-value');
  
  // Elementos de resultado
  const resultadoNomeProduto = document.getElementById('resultado-nome-produto');
  const resultadoQuantidade = document.getElementById('resultado-quantidade');
  const precoVenda = document.getElementById('preco-venda');
  const custoUnitarioTotal = document.getElementById('custo-unitario-total');
  const detMaterial = document.getElementById('det-material');
  const detMaoObra = document.getElementById('det-mao-obra');
  const detDespesas = document.getElementById('det-despesas');
  const detImpostos = document.getElementById('det-impostos');
  const detLucro = document.getElementById('det-lucro');
  const lucroTotal = document.getElementById('lucro-total');
  const detMargem = document.getElementById('det-margem');
  const lucroUnitario = document.getElementById('lucro-unitario');
  
  // Histórico
  const historicoBody = document.getElementById('historico-body');
  const btnSalvar = document.getElementById('salvar-calculo');
  
  // Atualizar valor do range
  margemRange.addEventListener('input', function() {
    margemValue.textContent = this.value + '%';
  });
  
  // Formatar moeda
  function formatarMoeda(valor) {
    return valor.toLocaleString('pt-BR', {
      style: 'currency',
      currency: 'BRL'
    });
  }
  
  // Formatar porcentagem
  function formatarPorcentagem(valor) {
    return valor.toFixed(1).replace('.', ',') + '%';
  }
  
  // Calcular preço de venda
  function calcularPrecoVenda(event) {
    event.preventDefault();
    
    // Validar campos
    if (!form.checkValidity()) {
      form.reportValidity();
      return;
    }
    
    // Obter valores
    const qtd = parseFloat(quantidade.value);
    const custoMat = parseFloat(custoMaterial.value);
    const maoObraVal = parseFloat(maoObra.value);
    const despesasVal = parseFloat(despesasGerais.value);
    const impostosPercent = parseFloat(impostos.value) / 100;
    const margemDesejada = parseFloat(margemRange.value) / 100;
    
    // Calcular custos unitários
    const custoUnitario = (custoMat + maoObraVal + despesasVal) / qtd;
    const lucroUnitarioVal = custoUnitario * margemDesejada;
    const precoVendaSemImpostos = custoUnitario + lucroUnitarioVal;
    const valorImpostos = precoVendaSemImpostos * impostosPercent;
    const precoVendaFinal = precoVendaSemImpostos + valorImpostos;
    
    // Calcular totais
    const lucroTotalVal = lucroUnitarioVal * qtd;
    
    // Atualizar UI
    resultadoNomeProduto.textContent = nomeProduto.value || "Produto sem nome";
    resultadoQuantidade.textContent = `Quantidade: ${qtd}`;
    precoVenda.textContent = formatarMoeda(precoVendaFinal);
    custoUnitarioTotal.textContent = formatarMoeda(custoUnitario);
    detMaterial.textContent = formatarMoeda(custoMat / qtd);
    detMaoObra.textContent = formatarMoeda(maoObraVal / qtd);
    detDespesas.textContent = formatarMoeda(despesasVal / qtd);
    detImpostos.textContent = `${formatarMoeda(valorImpostos)} (${formatarPorcentagem(impostosPercent * 100)})`;
    detLucro.textContent = `${formatarMoeda(lucroUnitarioVal)} (${formatarPorcentagem(margemDesejada * 100)})`;
    lucroTotal.textContent = formatarMoeda(lucroTotalVal);
    detMargem.textContent = formatarPorcentagem(margemDesejada * 100);
    lucroUnitario.textContent = formatarMoeda(lucroUnitarioVal);
  }
  
  async function salvarCalculo() {
    try {
      if (precoVenda.textContent === 'R$ 0,00') {
        alert('Calcule um preço antes de salvar!');
        return;
      }
    
      const nome = nomeProduto.value || "Produto sem nome";
      const qtd = quantidade.value;
      const custoUnit = custoUnitarioTotal.textContent.replace('R$', '').trim().replace('.', '').replace(',', '.');
      const preco = precoVenda.textContent.replace('R$', '').trim().replace('.', '').replace(',', '.');
      const lucroUnit = lucroUnitario.textContent.replace('R$', '').trim().replace('.', '').replace(',', '.');
      const margem = detMargem.textContent.replace('%', '').replace(',', '.');
    
      // Adiciona ao histórico HTML
      const newRow = document.createElement('tr');
      newRow.innerHTML = `
        <td>${nome}</td>
        <td>${qtd}</td>
        <td>R$ ${parseFloat(custoUnit).toFixed(2).replace('.', ',')}</td>
        <td>R$ ${parseFloat(preco).toFixed(2).replace('.', ',')}</td>
        <td>R$ ${parseFloat(lucroUnit).toFixed(2).replace('.', ',')}</td>
        <td>${parseFloat(margem).toFixed(1).replace('.', ',')}%</td>
      `;
      historicoBody.insertBefore(newRow, historicoBody.firstChild);
    
      // Limita o histórico a 10 itens
      if (historicoBody.children.length > 10) {
        historicoBody.removeChild(historicoBody.lastChild);
      }
    
      // Salva no Supabase
      const { data, error } = await supabase
        .from('calculos')
        .insert([
          {
            nome_produto: nome,
            quantidade: parseInt(qtd),
            custo_unitario: parseFloat(custoUnit),
            preco_venda: parseFloat(preco),
            lucro_unitario: parseFloat(lucroUnit),
            margem: parseFloat(margem),
            created_at: new Date().toISOString()
          }
        ]);
    
      if (error) {
        console.error('Erro ao salvar no Supabase:', error);
        alert('Erro ao salvar no banco de dados!');
        return;
      }
    
      console.log('Dados salvos com sucesso:', data);
      
      // Feedback visual
      btnSalvar.innerHTML = '<i class="fas fa-check"></i> Salvo com sucesso!';
      btnSalvar.classList.add('btn-success');
      setTimeout(() => {
        btnSalvar.innerHTML = '<i class="fas fa-save"></i> Salvar Cálculo';
        btnSalvar.classList.remove('btn-success');
      }, 2000);
      
    } catch (err) {
      console.error('Erro no processo de salvamento:', err);
      alert('Ocorreu um erro ao salvar os dados!');
    }
  }
  
  // Event listeners
  form.addEventListener('submit', calcularPrecoVenda);
  btnSalvar.addEventListener('click', salvarCalculo);
  
  // Carregar histórico do Supabase ao iniciar
  async function carregarHistorico() {
    try {
      const { data, error } = await supabase
        .from('calculos')
        .select('*')
        .order('created_at', { ascending: false })
        .limit(10);
      
      if (error) throw error;
      
      // Limpar histórico atual
      historicoBody.innerHTML = '';
      
      // Adicionar itens do banco de dados
      data.forEach(item => {
        const row = document.createElement('tr');
        row.innerHTML = `
          <td>${item.nome_produto}</td>
          <td>${item.quantidade}</td>
          <td>R$ ${item.custo_unitario.toFixed(2).replace('.', ',')}</td>
          <td>R$ ${item.preco_venda.toFixed(2).replace('.', ',')}</td>
          <td>R$ ${item.lucro_unitario.toFixed(2).replace('.', ',')}</td>
          <td>${item.margem.toFixed(1).replace('.', ',')}%</td>
        `;
        historicoBody.appendChild(row);
      });
      
    } catch (err) {
      console.error('Erro ao carregar histórico:', err);
    }
  }
  
  // Simular cálculo inicial para demonstração
  setTimeout(() => {
    nomeProduto.value = "Brigadeiro Gourmet";
    quantidade.value = 100;
    custoMaterial.value = 15.50;
    maoObra.value = 8.20;
    despesasGerais.value = 3.80;
    impostos.value = 12;
    margemRange.value = 30;
    margemValue.textContent = "30%";
    
    // Disparar evento de cálculo
    const event = new Event('submit');
    form.dispatchEvent(event);
    
    // Carregar histórico ao iniciar
    carregarHistorico();
  }, 500);
});