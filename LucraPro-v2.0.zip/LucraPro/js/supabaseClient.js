// supabaseClient.js
const SUPABASE_URL = 'https://ygowfhgytljosfjcjnud.supabase.co';
const SUPABASE_ANON_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Inlnb3dmaGd5dGxqb3NmamNqbnVkIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDg3MDY4MDMsImV4cCI6MjA2NDI4MjgwM30.KA82uRfKzJS6y6X_lDjEef3IzmhubTGOsrp1QWEgaAk';

const supabase = supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY);

export default supabase;