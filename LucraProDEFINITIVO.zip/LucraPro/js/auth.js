// auth.js - Configuração compartilhada por todas as páginas

// Configuração do Supabase
const SUPABASE_URL = 'https://ygowfhgytljosfjcjnud.supabase.co';
const SUPABASE_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Inlnb3dmaGd5dGxqb3NmamNqbnVkIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDg3MDY4MDMsImV4cCI6MjA2NDI4MjgwM30.KA82uRfKzJS6y6X_lDjEef3IzmhubTGOsrp1QWEgaAk';

// Inicializa o Supabase
const supabase = window.supabase.createClient(SUPABASE_URL, SUPABASE_KEY);

// Função para verificar autenticação
async function checkAuth() {
  const { data: { user }, error } = await supabase.auth.getUser();
  
  if (error || !user) {
    // Redireciona para a página de login se não estiver autenticado
    if (!window.location.pathname.endsWith('index.html')) {
      window.location.href = 'index.html';
    }
    return null;
  }
  
  // Atualiza a UI para mostrar o estado logado
  updateAuthUI();
  return user;
}

// Atualiza a interface do usuário com base no estado de autenticação
function updateAuthUI() {
  const loginBtn = document.getElementById('login-btn');
  const registerBtn = document.getElementById('register-btn');
  const profileBtn = document.getElementById('profile-btn');
  const logoutBtn = document.getElementById('logout-btn');
  
  if (loginBtn) loginBtn.style.display = 'none';
  if (registerBtn) registerBtn.style.display = 'none';
  if (profileBtn) profileBtn.style.display = 'inline-flex';
  if (logoutBtn) logoutBtn.style.display = 'inline-flex';
}

// Configura o logout
function setupLogout() {
  const logoutBtn = document.getElementById('logout-btn');
  if (logoutBtn) {
    logoutBtn.addEventListener('click', async (e) => {
      e.preventDefault();
      await supabase.auth.signOut();
      localStorage.removeItem('loggedIn');
      window.location.href = 'index.html';
    });
  }
}

// Função para obter o usuário logado
async function getCurrentUser() {
  const { data: { user }, error } = await supabase.auth.getUser();
  if (error) throw error;
  return user;
}

// Função para obter os dados do perfil do usuário
async function getUserProfile(userId) {
  const { data, error } = await supabase
    .from('usuarios')
    .select('*')
    .eq('id', userId)
    .single();
  
  if (error) throw error;
  return data;
}

// Função para atualizar o perfil do usuário
async function updateUserProfile(userId, updates) {
  const { data, error } = await supabase
    .from('usuarios')
    .update(updates)
    .eq('id', userId);
  
  if (error) throw error;
  return data;
}

// Função para verificar a senha do usuário
async function verifyPassword(email, password) {
  const { error } = await supabase.auth.signInWithPassword({
    email,
    password
  });
  
  if (error) throw error;
  return true;
}

// Exporta as funções
window.getCurrentUser = getCurrentUser;
window.getUserProfile = getUserProfile;
window.updateUserProfile = updateUserProfile;
window.verifyPassword = verifyPassword;
window.supabase = supabase;
window.checkAuth = checkAuth;
window.updateAuthUI = updateAuthUI;
window.setupLogout = setupLogout;