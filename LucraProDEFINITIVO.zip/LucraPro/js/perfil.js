import { supabase } from './config.js';

// Constantes
const MAX_AVATAR_SIZE = 2 * 1024 * 1024; // 2MB
const AVATAR_BUCKET_NAME = 'avatars';
const ALLOWED_IMAGE_TYPES = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];

// Cache de elementos DOM
const elements = {
  // Informações do usuário
  userName: document.getElementById('user-name'),
  userEmail: document.getElementById('user-email'),
  userPlan: document.getElementById('user-plan'),
  usernameDisplay: document.getElementById('username-display'),
  headerAvatar: document.getElementById('header-avatar'),
  
  // Formulário de perfil
  fullName: document.getElementById('full-name'),
  businessName: document.getElementById('business-name'),
  email: document.getElementById('perfil-email'),
  phone: document.getElementById('perfil-telefone'),
  bio: document.getElementById('bio'),
  
  // Botões
  editBtn: document.getElementById('edit-btn'),
  saveBtn: document.getElementById('save-btn'),
  cancelBtn: document.getElementById('cancel-btn'),
  
  // Avatar
  avatarImg: document.getElementById('avatar-img'),
  avatarUpload: document.getElementById('avatar-upload'),
  
  // Planos
  currentPlan: document.getElementById('current-plan'),
  planPrice: document.getElementById('plan-price'),
  planExpiration: document.getElementById('plan-expiration'),
  planProducts: document.getElementById('plan-products'),
  planStorage: document.getElementById('plan-storage'),
  planSelect: document.getElementById('plan-select'),
  
  // Modal
  confirmModal: document.getElementById('password-confirm-modal'),
  passwordForm: document.getElementById('password-confirm-form'),
  passwordInput: document.getElementById('confirm-password'),
  
  // Tabs
  tabs: document.querySelectorAll('.tab-btn'),
  tabContents: document.querySelectorAll('.tab-content')
};

// Estado da aplicação
const state = {
  currentUser: null,
  userProfile: null,
  originalData: {}
};

// ==================== FUNÇÕES DE AUTENTICAÇÃO ====================
async function checkAuth() {
  try {
    const { data: { session }, error } = await supabase.auth.getSession();
    
    if (error || !session) {
      showToast('Você precisa fazer login para acessar esta página', 'error');
      setTimeout(() => window.location.href = 'index.html', 2000);
      return false;
    }
    
    state.currentUser = session.user;
    return true;
  } catch (error) {
    console.error('Erro ao verificar autenticação:', error);
    showToast('Erro ao verificar autenticação', 'error');
    setTimeout(() => window.location.href = 'index.html', 2000);
    return false;
  }
}

// ==================== FUNÇÕES DE PERFIL ====================
async function getUserProfile(userId) {
  try {
    const { data, error } = await supabase
      .from('usuarios')
      .select('*')
      .eq('id', userId)
      .single();

    if (error && error.code !== 'PGRST116') throw error;
    
    return data || createDefaultProfile(userId);
  } catch (error) {
    console.error('Erro ao obter perfil:', error);
    throw error;
  }
}

function createDefaultProfile(userId) {
  return {
    id: userId,
    nome: state.currentUser.email.split('@')[0],
    email: state.currentUser.email,
    plano: 'basic',
    created_at: new Date().toISOString()
  };
}

async function updateUserProfile(updates) {
  try {
    updates.updated_at = new Date().toISOString();
    
    const { data, error } = await supabase
      .from('usuarios')
      .upsert({ id: state.currentUser.id, ...updates }, { onConflict: 'id' });
    
    if (error) throw error;
    return data;
  } catch (error) {
    console.error('Erro ao atualizar perfil:', error);
    throw error;
  }
}

// ==================== FUNÇÕES DE AVATAR ====================
async function handleAvatarUpload(file) {
  try {
    validateAvatarFile(file);
    
    // Mostra uma prévia da imagem imediatamente usando URL.createObjectURL
    const previewUrl = URL.createObjectURL(file);
    updateAvatarInUI(previewUrl);
    
    // Gera um nome único para o arquivo
    const fileExt = file.name.split('.').pop();
    const fileName = `${AVATAR_BUCKET_NAME}/${state.currentUser.id}/${Date.now()}.${fileExt}`;
    
    // Remove avatar antigo se existir
    await removeOldAvatarIfExists();
    
    // Faz upload do novo avatar
    const { error: uploadError } = await supabase.storage
      .from(AVATAR_BUCKET_NAME)
      .upload(fileName, file, {
        cacheControl: '3600',
        upsert: false,
        contentType: file.type
      });
    
    if (uploadError) throw uploadError;
    
    // Obtém URL pública
    const { data: { publicUrl } } = supabase.storage
      .from(AVATAR_BUCKET_NAME)
      .getPublicUrl(fileName);
    
    // Atualiza no banco de dados
    await updateUserProfile({ avatar_url: publicUrl });
    
    // Atualiza a UI com a URL permanente (com cache busting)
    updateAvatarInUI(`${publicUrl}?t=${Date.now()}`);
    
    // Libera a URL temporária
    URL.revokeObjectURL(previewUrl);
    
    showToast('Avatar atualizado com sucesso!', 'success');
  } catch (error) {
    console.error('Erro ao atualizar avatar:', error);
    showToast(error.message || 'Erro ao atualizar avatar. Verifique o console para detalhes.', 'error');
    
    // Reverte para a imagem anterior em caso de erro
    if (state.userProfile?.avatar_url) {
      updateAvatarInUI(state.userProfile.avatar_url);
    }
  }
}

function validateAvatarFile(file) {
  if (!ALLOWED_IMAGE_TYPES.includes(file.type)) {
    throw new Error('Tipo de arquivo não suportado. Use JPEG, PNG, GIF ou WebP.');
  }
  
  if (file.size > MAX_AVATAR_SIZE) {
    throw new Error(`A imagem deve ter menos de ${MAX_AVATAR_SIZE / 1024 / 1024}MB`);
  }
}

async function uploadAvatarFile(file) {
  const fileName = `avatar-${state.currentUser.id}-${Date.now()}.${file.name.split('.').pop()}`;
  
  // Remove avatar antigo se existir
  await removeOldAvatarIfExists();
  
  // Faz upload do novo avatar
  const { error: uploadError } = await supabase.storage
    .from(AVATAR_BUCKET_NAME)
    .upload(fileName, file, {
      cacheControl: '3600',
      upsert: true
    });
  
  if (uploadError) throw uploadError;
  
  return fileName;
}

async function removeOldAvatarIfExists() {
  if (!state.userProfile?.avatar_url) return;
  
  try {
    // Extrai o caminho do arquivo da URL
    const url = new URL(state.userProfile.avatar_url);
    const filePath = url.pathname.split('/storage/v1/object/public/avatars/')[1];
    
    if (filePath) {
      const { error } = await supabase.storage
        .from(AVATAR_BUCKET_NAME)
        .remove([filePath]);
      
      if (error) console.warn('Não foi possível remover o avatar antigo:', error);
    }
  } catch (error) {
    console.warn('Erro ao processar URL do avatar antigo:', error);
  }
}

function getAvatarPublicUrl(filePath) {
  const { data: { publicUrl } } = supabase.storage
    .from(AVATAR_BUCKET_NAME)
    .getPublicUrl(filePath);
  
  return publicUrl;
}

function updateAvatarInUI(avatarUrl) {
  state.userProfile.avatar_url = avatarUrl;
  
  const avatarImg = elements.avatarImg;
  const headerAvatar = elements.headerAvatar;
  
  if (avatarUrl) {
    // Se for uma URL de imagem
    if (avatarImg.tagName === 'IMG') {
      avatarImg.src = avatarUrl;
      headerAvatar.src = avatarUrl;
    } 
    // Se for um SVG (imagem padrão)
    else if (avatarImg.tagName === 'svg') {
      // Substitui o SVG por uma tag IMG
      const newImg = document.createElement('img');
      newImg.id = 'avatar-img';
      newImg.src = avatarUrl;
      newImg.alt = 'Foto do perfil';
      newImg.className = 'avatar-img';
      avatarImg.parentNode.replaceChild(newImg, avatarImg);
      elements.avatarImg = newImg;
      
      // Atualiza o avatar do header
      headerAvatar.src = avatarUrl;
    }
  }
}

// ==================== FUNÇÕES DE UI ====================
function updateUIWithProfileData() {
  const { currentUser, userProfile } = state;
  const displayName = userProfile.nome || currentUser.email.split('@')[0];
  
  // Informações do usuário
  elements.userName.textContent = displayName;
  elements.userEmail.textContent = currentUser.email;
  elements.userPlan.textContent = capitalizeFirstLetter(userProfile.plano || 'basic');
  elements.usernameDisplay.textContent = displayName;
  
  // Formulário
  elements.fullName.value = userProfile.nome || '';
  elements.businessName.value = userProfile.negocio || '';
  elements.email.value = currentUser.email;
  elements.phone.value = userProfile.telefone || '';
  elements.bio.value = userProfile.bio || '';
  
  // Avatar
  if (userProfile.avatar_url) {
    updateAvatarInUI(userProfile.avatar_url);
  }
  
  // Plano
  loadPlanData(userProfile.plano || 'basic');
  
  // Salva dados originais para comparação
  state.originalData = {
    nome: userProfile.nome || '',
    negocio: userProfile.negocio || '',
    telefone: userProfile.telefone || '',
    bio: userProfile.bio || ''
  };
}

function loadPlanData(plan) {
  const PLANS = {
    basic: {
      name: 'Básico',
      price: 'R$ 19,90/mês',
      expiration: '--/--/----',
      products: '--',
      storage: '--'
    },
    premium: {
      name: 'Premium',
      price: 'R$ 49,90/mês',
      expiration: '--/--/----',
      products: '--',
      storage: '--'
    },
    enterprise: {
      name: 'Enterprise',
      price: 'R$ 99,90/mês',
      expiration: '--/--/----',
      products: '--',
      storage: '--'
    }
  };

  const selectedPlan = PLANS[plan] || PLANS.basic;
  
  elements.currentPlan.textContent = selectedPlan.name;
  elements.planPrice.textContent = selectedPlan.price;
  elements.planExpiration.textContent = selectedPlan.expiration;
  elements.planProducts.textContent = selectedPlan.products;
  elements.planStorage.textContent = selectedPlan.storage;
  elements.planSelect.value = plan;
  
  // Desativa a funcionalidade de atualização de plano
  document.getElementById('update-plan-btn').disabled = true;
  document.getElementById('plan-select').disabled = true;
}

function toggleEditMode(enable) {
  const editableFields = [
    elements.fullName, 
    elements.businessName, 
    elements.phone, 
    elements.bio
  ];
  
  editableFields.forEach(input => {
    input.disabled = !enable;
  });
  
  elements.editBtn.style.display = enable ? 'none' : 'block';
  elements.saveBtn.style.display = enable ? 'block' : 'none';
  elements.cancelBtn.style.display = enable ? 'block' : 'none';
}

function hasChanges() {
  return (
    elements.fullName.value !== state.originalData.nome ||
    elements.businessName.value !== state.originalData.negocio ||
    elements.phone.value !== state.originalData.telefone ||
    elements.bio.value !== state.originalData.bio
  );
}

// ==================== FUNÇÕES DE NOTIFICAÇÃO ====================
function showToast(message, type = 'success', duration = 5000) {
  const toastContainer = document.getElementById('toast-container');
  if (!toastContainer) return;
  
  const toast = document.createElement('div');
  toast.className = `toast toast-${type} show`;
  
  const iconMap = {
    success: 'check-circle',
    error: 'exclamation-circle',
    info: 'info-circle',
    warning: 'exclamation-triangle'
  };
  
  toast.innerHTML = `
    <div class="toast-icon"><i class="fas fa-${iconMap[type] || 'info-circle'}"></i></div>
    <div class="toast-message">${message}</div>
    <button class="toast-close">&times;</button>
  `;
  
  toastContainer.appendChild(toast);
  
  toast.querySelector('.toast-close').addEventListener('click', () => toast.remove());
  
  if (duration > 0) {
    setTimeout(() => toast.remove(), duration);
  }
}

// ==================== FUNÇÕES DE EVENTOS ====================
async function handleSaveProfile() {
  if (!hasChanges()) {
    showToast('Nenhuma alteração detectada', 'info');
    toggleEditMode(false);
    return;
  }
  
  elements.confirmModal.classList.add('active');
  elements.passwordInput.focus();
}

async function confirmPasswordAndSave(e) {
  e.preventDefault();
  const password = elements.passwordInput.value;
  
  try {
    // Verificar senha
    const { error } = await supabase.auth.signInWithPassword({
      email: state.currentUser.email,
      password
    });
    
    if (error) throw error;
    
    // Fechar modal
    elements.confirmModal.classList.remove('active');
    elements.passwordInput.value = '';
    
    // Atualizar perfil
    const updates = {
      nome: elements.fullName.value,
      negocio: elements.businessName.value,
      telefone: elements.phone.value,
      bio: elements.bio.value
    };
    
    await updateUserProfile(updates);
    state.userProfile = { ...state.userProfile, ...updates };
    updateUIWithProfileData();
    showToast('Perfil atualizado com sucesso!', 'success');
    toggleEditMode(false);
    
  } catch (error) {
    console.error('Erro ao verificar senha:', error);
    showToast('Senha incorreta', 'error');
    elements.passwordInput.value = '';
  }
}

async function handlePlanUpdate() {
  showToast('A funcionalidade de atualização de planos estará disponível em breve!', 'info');
}

async function handlePasswordUpdate() {
  const currentPassword = document.getElementById('current-password').value;
  const newPassword = document.getElementById('new-password').value;
  const confirmPassword = document.getElementById('confirm-new-password').value;

  // Validações básicas
  if (!currentPassword || !newPassword || !confirmPassword) {
    showToast('Preencha todos os campos', 'error');
    return;
  }

  if (newPassword !== confirmPassword) {
    showToast('As senhas não coincidem', 'error');
    return;
  }

  if (newPassword.length < 6) {
    showToast('A senha deve ter pelo menos 6 caracteres', 'error');
    return;
  }

  try {
    // Primeiro verifica a senha atual
    const { error: authError } = await supabase.auth.signInWithPassword({
      email: state.currentUser.email,
      password: currentPassword
    });

    if (authError) throw authError;

    // Atualiza a senha
    const { error: updateError } = await supabase.auth.updateUser({
      password: newPassword
    });

    if (updateError) throw updateError;

    // Limpa os campos e mostra mensagem de sucesso
    document.getElementById('current-password').value = '';
    document.getElementById('new-password').value = '';
    document.getElementById('confirm-new-password').value = '';

    showToast('Senha atualizada com sucesso!', 'success');
  } catch (error) {
    console.error('Erro ao atualizar senha:', error);
    showToast(error.message || 'Erro ao atualizar senha. Verifique a senha atual.', 'error');
  }
}

function setupTabs() {
  elements.tabs.forEach(tab => {
    tab.addEventListener('click', () => {
      elements.tabs.forEach(t => t.classList.remove('active'));
      elements.tabContents.forEach(c => c.classList.remove('active'));
      
      tab.classList.add('active');
      
      const tabId = tab.getAttribute('data-tab');
      const content = document.getElementById(`${tabId}-panel`);
      if (content) content.classList.add('active');
    });
  });
  
  // Ativar tab padrão
  const activeTab = document.querySelector('.tab-btn.active');
  if (activeTab) {
    const tabId = activeTab.getAttribute('data-tab');
    const content = document.getElementById(`${tabId}-panel`);
    if (content) content.classList.add('active');
  }
}

function setupLogout() {
  const logoutBtn = document.getElementById('logout-btn');
  if (logoutBtn) {
    logoutBtn.addEventListener('click', async (e) => {
      e.preventDefault();
      await supabase.auth.signOut();
      localStorage.removeItem('loggedIn');
      showToast('Você saiu com sucesso!', 'success');
      setTimeout(() => window.location.href = 'index.html', 1500);
    });
  }
}

function setupEventListeners() {
  // Edição de perfil
  if (elements.editBtn) elements.editBtn.addEventListener('click', () => toggleEditMode(true));
  if (elements.cancelBtn) elements.cancelBtn.addEventListener('click', resetForm);
  if (elements.saveBtn) elements.saveBtn.addEventListener('click', handleSaveProfile);
  
  // Avatar
  if (elements.avatarUpload) {
    elements.avatarUpload.addEventListener('change', (e) => {
      const file = e.target.files[0];
      if (file) handleAvatarUpload(file);
    });
  }
  
  // Plano
  const updatePlanBtn = document.getElementById('update-plan-btn');
  if (updatePlanBtn) updatePlanBtn.addEventListener('click', handlePlanUpdate);

  //Senha
    const updatePasswordBtn = document.getElementById('update-password-btn');
  if (updatePasswordBtn) {
    updatePasswordBtn.addEventListener('click', handlePasswordUpdate);
  }
  
  // Modal de confirmação
  if (elements.passwordForm) {
    elements.passwordForm.addEventListener('submit', confirmPasswordAndSave);
  }
  
  // Fechar modal
  document.querySelectorAll('[data-modal-close]').forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.preventDefault();
      closeModal();
    });
  });
  
  // Alternar visibilidade da senha
  document.querySelectorAll('.toggle-password').forEach(btn => {
    btn.addEventListener('click', function() {
      const input = this.previousElementSibling;
      if (input) togglePasswordVisibility(input, this.querySelector('i'));
    });
  });
}

function resetForm() {
  elements.fullName.value = state.originalData.nome;
  elements.businessName.value = state.originalData.negocio;
  elements.phone.value = state.originalData.telefone;
  elements.bio.value = state.originalData.bio;
  toggleEditMode(false);
}

function closeModal() {
  elements.confirmModal?.classList.remove('active');
  elements.passwordInput.value = '';
}

function togglePasswordVisibility(input, icon) {
  const type = input.getAttribute('type') === 'password' ? 'text' : 'password';
  input.setAttribute('type', type);
  
  if (icon) {
    icon.classList.toggle('fa-eye');
    icon.classList.toggle('fa-eye-slash');
  }
}

function capitalizeFirstLetter(string) {
  return string.charAt(0).toUpperCase() + string.slice(1);
}

// ==================== INICIALIZAÇÃO ====================
async function loadUserData() {
  try {
    const isAuthenticated = await checkAuth();
    if (!isAuthenticated) return;
    
    state.userProfile = await getUserProfile(state.currentUser.id);
    
    if (!state.userProfile.created_at) {
      await updateUserProfile(state.userProfile);
      state.userProfile = await getUserProfile(state.currentUser.id);
    }
    
    updateUIWithProfileData();
  } catch (error) {
    console.error('Erro ao carregar dados:', error);
    showToast('Erro ao carregar dados. Tente recarregar.', 'error');
  }
}

async function initialize() {
  try {
    await loadUserData();
    setupEventListeners();
    setupTabs();
    setupLogout();
  } catch (error) {
    console.error('Erro na inicialização:', error);
    showToast('Erro ao carregar a página. Tente recarregar.', 'error');
  }
}

document.addEventListener('DOMContentLoaded', initialize);