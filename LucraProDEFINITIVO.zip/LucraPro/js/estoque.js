console.log('checkAuth:', typeof checkAuth);

document.addEventListener('DOMContentLoaded', async () => {
  const user = await checkAuth();

  setupLogout();

  // Atualiza interface de autenticação com base no estado atual
  if (user) {
    document.getElementById('register-btn').style.display = 'none';
    document.getElementById('login-btn').style.display = 'none';
    document.getElementById('logout-btn').style.display = 'inline-block';
    document.getElementById('profile-btn').style.display = 'inline-block';

    const userIndicator = document.getElementById('user-indicator');
    if (userIndicator) userIndicator.style.display = 'none';
  } else {
    document.getElementById('logout-btn').style.display = 'none';
    document.getElementById('profile-btn').style.display = 'none';
    document.getElementById('login-btn').style.display = 'inline-block';
    document.getElementById('register-btn').style.display = 'inline-block';
  }

  if (!user) return;

  let produtoSelecionado = null;
  let grafico = null;
  let dadosProdutos = {};

  const selectProduto = document.getElementById('produto-estoque');

  async function carregarEstoqueUsuario() {
    const { data, error } = await supabase
      .from('Estoque')
      .select('*')
      .eq('user_id', user.id);

    if (error) {
      console.error('Erro ao carregar estoque:', error);
      alert('Erro ao carregar o estoque do usuário.');
      return;
    }

    dadosProdutos = {};
    selectProduto.innerHTML = '<option value="" disabled selected>Selecione um produto</option>';

    data.forEach((item) => {
      dadosProdutos[item.nome_produto] = item;

      const option = document.createElement('option');
      option.value = item.nome_produto;
      option.textContent = item.nome_produto;
      selectProduto.appendChild(option);
    });
  }

  function atualizarInfo(produto) {
    const info = dadosProdutos[produto];

    document.getElementById('estoque-atual').textContent = info.estoque_atual;
    document.getElementById('preco-produto').textContent = `R$ ${info.preco.toFixed(2)}`;
    document.getElementById('quantidade-vendida').textContent = info.quantidade_vendida;
    document.getElementById('retorno-bruto').textContent = `R$ ${info.retorno_bruto.toFixed(2)}`;
    document.getElementById('estoque-info').style.display = 'block';

    const lucro = info.retorno_bruto - (info.quantidade_vendida * info.custo_unitario);
    document.getElementById('lucro-obtido').textContent = `R$ ${lucro.toFixed(2)}`;

    atualizarGrafico(info);
  }

  async function atualizarEstoqueNoSupabase(novoEstoque) {
    const produto = dadosProdutos[produtoSelecionado];
    const margemContribuicao = produto.preco - produto.custo_unitario;
    const pontoEquilibrio = margemContribuicao > 0 
      ? Math.ceil(produto.despesas_fixas / margemContribuicao)
      : 0;
    const retornoBruto = produto.preco * produto.quantidade_vendida;

    const { error } = await supabase
      .from('Estoque')
      .update({
        estoque_atual: novoEstoque,
        ponto_equilibrio: pontoEquilibrio,
        retorno_bruto: retornoBruto
      })
      .eq('user_id', user.id)
      .eq('nome_produto', produtoSelecionado);

    if (error) {
      console.error('Erro ao atualizar estoque:', error);
      alert('Erro ao atualizar o estoque!');
      return;
    }

    produto.estoque_atual = novoEstoque;
    produto.ponto_equilibrio = pontoEquilibrio;
    produto.retorno_bruto = retornoBruto;

    atualizarInfo(produtoSelecionado);
  }

  function atualizarGrafico(info) {
    const ctx = document.getElementById('grafico-estoque').getContext('2d');
    if (grafico) grafico.destroy();

    grafico = new Chart(ctx, {
      type: 'bar',
      data: {
        labels: ['Estoque Atual', 'Quantidade Vendida'],
        datasets: [{
          label: 'Unidades',
          data: [info.estoque_atual, info.quantidade_vendida],
          backgroundColor: ['#4CAF50', '#FF9800']
        }]
      },
      options: {
        responsive: true,
        scales: { y: { beginAtZero: true, precision: 0 } }
      }
    });
  }

  selectProduto.addEventListener('change', () => {
    produtoSelecionado = selectProduto.value;
    atualizarInfo(produtoSelecionado);
  });

  document.getElementById('btn-atualizar-estoque').addEventListener('click', () => {
    abrirModalEstoque("Atualizar Estoque", async (novoEstoque) => {
      await atualizarEstoqueNoSupabase(novoEstoque);
      mostrarToast("Estoque atualizado com sucesso!", 'success');
    });
  });

  document.getElementById('btn-registrar-reposicao').addEventListener('click', () => {
    abrirModalEstoque("Registrar Reposição", async (valor) => {
      const atual = dadosProdutos[produtoSelecionado].estoque_atual + valor;
      await atualizarEstoqueNoSupabase(atual);
      mostrarToast("Reposição registrada com sucesso!", 'success');
    });
  });

  document.getElementById('btn-registrar-baixa').addEventListener('click', () => {
    abrirModalEstoque("Registrar Baixa", async (valor) => {
      const atual = dadosProdutos[produtoSelecionado].estoque_atual;
      if (valor > atual) {
        mostrarToast("Valor maior que o estoque atual!", 'error');
        return;
      }
      await atualizarEstoqueNoSupabase(atual - valor);
      mostrarToast("Baixa registrada com sucesso!", 'success');
    });
  });

  await carregarEstoqueUsuario();
});

function abrirModalEstoque(titulo, callback) {
  const modal = document.getElementById('modal-estoque');
  const input = document.getElementById('modal-input');
  const btnConfirmar = document.getElementById('modal-confirmar');
  const btnCancelar = document.getElementById('modal-cancelar');

  document.getElementById('modal-titulo').textContent = titulo;
  input.value = '';
  modal.style.display = 'flex';
  input.focus();

  const confirmar = () => {
    const valor = parseInt(input.value);
    if (isNaN(valor)) {
      mostrarToast('Digite um valor válido!', 'error');
      return;
    }
    modal.style.display = 'none';
    btnConfirmar.removeEventListener('click', confirmar);
    callback(valor);
  };

  btnConfirmar.addEventListener('click', confirmar);
  btnCancelar.onclick = () => (modal.style.display = 'none');
}

function mostrarToast(mensagem, tipo = 'success') {
  const toast = document.createElement('div');
  toast.className = `toast ${tipo}`;
  toast.textContent = mensagem;

  document.body.appendChild(toast);

  setTimeout(() => {
    toast.classList.add('show');
  }, 10);

  setTimeout(() => {
    toast.classList.remove('show');
    setTimeout(() => {
      document.body.removeChild(toast);
    }, 300);
  }, 3500);
}



