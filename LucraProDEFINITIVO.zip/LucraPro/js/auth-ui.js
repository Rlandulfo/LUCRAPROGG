// auth-ui.js

// Função para inicializar interface de autenticação
export async function setupAuthUI(supabase) {
    try {
      const { data: { user }, error } = await supabase.auth.getUser();
  
      const loginBtn = document.getElementById('login-btn');
      const registerBtn = document.getElementById('register-btn');
      const profileBtn = document.getElementById('profile-btn');
      const logoutBtn = document.getElementById('logout-btn');
      const userIndicator = document.getElementById('user-indicator');
  
      if (user) {
        if (loginBtn) loginBtn.style.display = 'none';
        if (registerBtn) registerBtn.style.display = 'none';
        if (profileBtn) profileBtn.style.display = 'inline-block';
        if (logoutBtn) logoutBtn.style.display = 'inline-block';
        if (userIndicator) userIndicator.style.display = 'none';
  
        // Marcar como logado
        localStorage.setItem('loggedIn', 'true');
      } else {
        if (loginBtn) loginBtn.style.display = 'inline-block';
        if (registerBtn) registerBtn.style.display = 'inline-block';
        if (profileBtn) profileBtn.style.display = 'none';
        if (logoutBtn) logoutBtn.style.display = 'none';
  
        localStorage.removeItem('loggedIn');
      }
  
      // Configurar botão de logout
      if (logoutBtn) {
        logoutBtn.addEventListener('click', async (e) => {
          e.preventDefault();
          await supabase.auth.signOut();
          localStorage.removeItem('loggedIn');
          window.location.href = 'index.html';
        });
      }
  
      return user;
  
    } catch (err) {
      console.error('Erro ao configurar UI de autenticação:', err);
      return null;
    }
  }
  