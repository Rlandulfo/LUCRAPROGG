// navbar.js
document.addEventListener('DOMContentLoaded', function() {
  // Carrega a navbar
  fetch('navbar.html')
    .then(response => response.text())
    .then(html => {
      document.getElementById('navbar-container').innerHTML = html;
      
      // Inicializa os eventos da navbar
      initNavbar();
    });
});

function initNavbar() {
  // Menu Mobile
  const mobileMenuBtn = document.querySelector('.mobile-menu-btn');
  const navList = document.querySelector('.nav-list');
  
  if (mobileMenuBtn && navList) {
    mobileMenuBtn.addEventListener('click', function() {
      const isExpanded = this.getAttribute('aria-expanded') === 'true';
      this.setAttribute('aria-expanded', !isExpanded);
      navList.classList.toggle('active');
      document.body.style.overflow = isExpanded ? 'auto' : 'hidden';
    });
  }
  
  // Fechar menu ao clicar em um link
  const navLinks = document.querySelectorAll('.nav-link');
  if (navLinks.length > 0 && navList && mobileMenuBtn) {
    navLinks.forEach(link => {
      link.addEventListener('click', function() {
        navList.classList.remove('active');
        mobileMenuBtn.setAttribute('aria-expanded', 'false');
        document.body.style.overflow = 'auto';
      });
    });
  }

  // Ativar link ativo na navegação
  const currentPage = window.location.pathname.split('/').pop() || 'index.html';
  document.querySelectorAll('.nav-link').forEach(link => {
    const linkPage = link.getAttribute('href');
    if (linkPage === currentPage) {
      link.classList.add('active');
    }
  });
}