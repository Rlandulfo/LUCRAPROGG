console.log('checkAuth:', typeof checkAuth);

document.addEventListener('DOMContentLoaded', async () => {
  const user = await checkAuth();
  if (!user) return;

  setupLogout();

  let produtoSelecionado = null;
  let grafico = null;
  let dadosProdutos = {};

  const selectProduto = document.getElementById('produto-estoque');

  async function carregarEstoqueUsuario() {
    const { data, error } = await supabase
      .from('Estoque')
      .select('*')
      .eq('user_id', user.id);

    if (error) {
      console.error('Erro ao carregar estoque:', error);
      alert('Erro ao carregar o estoque do usuário.');
      return;
    }

    dadosProdutos = {};
    selectProduto.innerHTML = '<option value="" disabled selected>Selecione um produto</option>';

    data.forEach((item) => {
      dadosProdutos[item.nome_produto] = item;

      const option = document.createElement('option');
      option.value = item.nome_produto;
      option.textContent = item.nome_produto;
      selectProduto.appendChild(option);
    });
  }

  function atualizarInfo(produto) {
    const info = dadosProdutos[produto];

    document.getElementById('estoque-atual').textContent = info.estoque_atual;
    document.getElementById('preco-produto').textContent = `R$ ${info.preco.toFixed(2)}`;
    document.getElementById('ponto-equilibrio').textContent = `${info.ponto_equilibrio} unidades`;
    document.getElementById('quantidade-vendida').textContent = info.quantidade_vendida;
    document.getElementById('retorno-bruto').textContent = `R$ ${info.retorno_bruto.toFixed(2)}`;
    document.getElementById('estoque-info').style.display = 'block';

    atualizarGrafico(info);
  }

  async function atualizarEstoqueNoSupabase(novoEstoque) {
    const produto = dadosProdutos[produtoSelecionado];

    const pontoEquilibrio = Math.ceil(produto.custo_unitario / (produto.preco - produto.custo_unitario));
    const retornoBruto = produto.preco * produto.quantidade_vendida;

    const { error } = await supabase
      .from('Estoque')
      .update({
        estoque_atual: novoEstoque,
        ponto_equilibrio: pontoEquilibrio,
        retorno_bruto: retornoBruto
      })
      .eq('user_id', user.id)
      .eq('nome_produto', produtoSelecionado);

    if (error) {
      console.error('Erro ao atualizar estoque:', error);
      alert('Erro ao atualizar o estoque!');
      return;
    }

    // Atualiza o objeto local
    produto.estoque_atual = novoEstoque;
    produto.ponto_equilibrio = pontoEquilibrio;
    produto.retorno_bruto = retornoBruto;

    atualizarInfo(produtoSelecionado);
  }

  // Eventos
  selectProduto.addEventListener('change', () => {
    produtoSelecionado = selectProduto.value;
    atualizarInfo(produtoSelecionado);
  });

  document.getElementById('btn-atualizar-estoque').addEventListener('click', async () => {
    const novoEstoque = parseInt(prompt("Digite o novo estoque:"));
    if (!isNaN(novoEstoque)) {
      await atualizarEstoqueNoSupabase(novoEstoque);
      alert("Estoque atualizado com sucesso!");
    } else {
      alert("Valor inválido.");
    }
  });

  document.getElementById('btn-registrar-reposicao').addEventListener('click', async () => {
    const valor = parseInt(prompt("Digite a quantidade a repor:"));
    if (!isNaN(valor)) {
      const atual = dadosProdutos[produtoSelecionado].estoque_atual + valor;
      await atualizarEstoqueNoSupabase(atual);
      alert("Reposição registrada!");
    } else {
      alert("Valor inválido.");
    }
  });

  document.getElementById('btn-registrar-baixa').addEventListener('click', async () => {
    const valor = parseInt(prompt("Digite a quantidade a dar baixa:"));
    const atual = dadosProdutos[produtoSelecionado].estoque_atual;
    if (!isNaN(valor) && valor <= atual) {
      await atualizarEstoqueNoSupabase(atual - valor);
      alert("Baixa registrada!");
    } else {
      alert("Valor inválido ou maior que o estoque atual.");
    }
  });

  function atualizarGrafico(info) {
    const ctx = document.getElementById('grafico-estoque').getContext('2d');
    if (grafico) grafico.destroy();

    grafico = new Chart(ctx, {
      type: 'bar',
      data: {
        labels: ['Estoque Atual', 'Quantidade Vendida'],
        datasets: [{
          label: 'Unidades',
          data: [info.estoque_atual, info.quantidade_vendida],
          backgroundColor: ['#4CAF50', '#FF9800']
        }]
      },
      options: {
        responsive: true,
        scales: { y: { beginAtZero: true, precision: 0 } }
      }
    });
  }

  // Carregar dados iniciais
  await carregarEstoqueUsuario();
});


  
  // Gráfico
  function atualizarGrafico(info) {
    const ctx = document.getElementById('grafico-estoque').getContext('2d');
    
    if (grafico) {
      grafico.destroy();
    }
    
    grafico = new Chart(ctx, {
      type: 'bar',
      data: {
        labels: ['Estoque Atual', 'Quantidade Vendida'],
        datasets: [{
          label: 'Unidades',
          data: [info.estoque_atual, info.quantidade_vendida],
          backgroundColor: ['#4CAF50', '#FF9800']
        }]
      },
      options: {
        responsive: true,
        scales: {
          y: {
            beginAtZero: true,
            precision: 0
          }
        }
      }
    });
  }
  