document.addEventListener('DOMContentLoaded', async function() {
  // Verifica se a página atual não é a index.html
  if (!window.location.pathname.endsWith('index.html')) {
    try {
      const user = await checkAuth();
      if (!user) {
        window.location.href = 'index.html';
      }
    } catch (error) {
      console.error('Erro na verificação de autenticação:', error);
      window.location.href = 'index.html';
    }
  }
});