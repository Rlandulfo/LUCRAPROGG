document.addEventListener('DOMContentLoaded', async function() {
  // 1. Verificar autenticação
  const user = await checkAuth();
  if (!user) {
    window.location.href = 'index.html';
    return;
  }

  // 2. Configurar logout
  setupLogout();

  // Elementos do DOM
  const form = document.getElementById('form-calculadora');
  const nomeProduto = document.getElementById('nome-produto');
  const quantidade = document.getElementById('quantidade');
  const custoMaterial = document.getElementById('custo-material');
  const maoObra = document.getElementById('mao-obra');
  const despesasGerais = document.getElementById('despesas-gerais');
  const impostos = document.getElementById('impostos');
  const margemRange = document.getElementById('margem-range');
  const margemValue = document.getElementById('margem-value');
  const resultadoNomeProduto = document.getElementById('resultado-nome-produto');
  const resultadoQuantidade = document.getElementById('resultado-quantidade');
  const precoVenda = document.getElementById('preco-venda');
  const custoUnitarioTotal = document.getElementById('custo-unitario-total');
  const detMaterial = document.getElementById('det-material');
  const detMaoObra = document.getElementById('det-mao-obra');
  const detDespesas = document.getElementById('det-despesas');
  const detImpostos = document.getElementById('det-impostos');
  const detLucro = document.getElementById('det-lucro');
  const lucroTotal = document.getElementById('lucro-total');
  const detMargem = document.getElementById('det-margem');
  const lucroUnitario = document.getElementById('lucro-unitario');
  const historicoBody = document.getElementById('historico-body');
  const btnSalvar = document.getElementById('salvar-calculo');

  // Funções auxiliares
  function formatarMoeda(valor) {
    return valor.toLocaleString('pt-BR', {
      style: 'currency',
      currency: 'BRL'
    });
  }

  function formatarPorcentagem(valor) {
    return valor.toFixed(1).replace('.', ',') + '%';
  }

  function mostrarToast(mensagem, tipo = 'success') {
    const toast = document.createElement('div');
    toast.className = `toast show ${tipo}`;
    toast.textContent = mensagem;
    document.body.appendChild(toast);

    setTimeout(() => {
      toast.classList.remove('show');
      setTimeout(() => document.body.removeChild(toast), 300);
    }, 3000);
  }

  // Funções de carregamento de dados
  async function carregarProdutosUsuario() {
    const user = await getCurrentUser();
    const datalist = document.getElementById('lista-produtos');
    datalist.innerHTML = '';

    const { data, error } = await supabase
      .from('produtos')
      .select('nome')
      .eq('user_id', user.id);

    if (!error && data) {
      data.forEach(produto => {
        const option = document.createElement('option');
        option.value = produto.nome;
        datalist.appendChild(option);
      });
    }
  }

  async function carregarHistorico() {
    try {
      const user = await getCurrentUser();
      
      const { data, error } = await supabase
        .from('calculos')
        .select('*')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false })
        .limit(10);
      
      if (error) throw error;
      
      historicoBody.innerHTML = '';
      
      data.forEach(item => {
        const row = document.createElement('tr');
        row.innerHTML = `
          <td>${item.nome_produto}</td>
          <td>${item.quantidade}</td>
          <td>R$ ${item.custo_unitario.toFixed(2).replace('.', ',')}</td>
          <td>R$ ${item.preco_venda.toFixed(2).replace('.', ',')}</td>
          <td>R$ ${item.lucro_unitario.toFixed(2).replace('.', ',')}</td>
          <td>${item.margem.toFixed(1).replace('.', ',')}%</td>
        `;
        historicoBody.appendChild(row);
      });
      
    } catch (err) {
      console.error('Erro ao carregar histórico:', err);
      mostrarToast('❌ Erro ao carregar histórico', 'error');
    }
  }

  // Funções de cálculo
  function calcularPrecoVenda(event) {
    event.preventDefault();
    
    if (!form.checkValidity()) {
      form.reportValidity();
      return;
    }
    
    const qtd = parseFloat(quantidade.value);
    const custoMat = parseFloat(custoMaterial.value);
    const maoObraVal = parseFloat(maoObra.value);
    const despesasVal = parseFloat(despesasGerais.value);
    const impostosPercent = parseFloat(impostos.value) / 100;
    const margemDesejada = parseFloat(margemRange.value) / 100;
    
    const custoUnitario = (custoMat + maoObraVal + despesasVal) / qtd;
    const lucroUnitarioVal = custoUnitario * margemDesejada;
    const precoVendaSemImpostos = custoUnitario + lucroUnitarioVal;
    const valorImpostos = precoVendaSemImpostos * impostosPercent;
    const precoVendaFinal = precoVendaSemImpostos + valorImpostos;
    const lucroTotalVal = lucroUnitarioVal * qtd;
    
    // Atualizar UI
    resultadoNomeProduto.textContent = nomeProduto.value || "Produto sem nome";

    precoVenda.textContent = formatarMoeda(precoVendaFinal);
    custoUnitarioTotal.textContent = formatarMoeda(custoUnitario);
    detMaterial.textContent = formatarMoeda(custoMat / qtd);
    detMaoObra.textContent = formatarMoeda(maoObraVal / qtd);
    detDespesas.textContent = formatarMoeda(despesasVal / qtd);
    detImpostos.textContent = `${formatarMoeda(valorImpostos)} (${formatarPorcentagem(impostosPercent * 100)})`;
    detLucro.textContent = `${formatarMoeda(lucroUnitarioVal)} (${formatarPorcentagem(margemDesejada * 100)})`;
    lucroTotal.textContent = formatarMoeda(lucroTotalVal);
    detMargem.textContent = formatarPorcentagem(margemDesejada * 100);
    lucroUnitario.textContent = formatarMoeda(lucroUnitarioVal);
  }

  // Funções de persistência
  async function salvarCalculo() {
    try {
      const user = await getCurrentUser();
      
      if (precoVenda.textContent === 'R$ 0,00') {
        mostrarToast('❌ Calcule um preço antes de salvar!', 'error');
        return;
      }
    
      const nome = nomeProduto.value || "Produto sem nome";
      const qtd = quantidade.value;
      const custoUnit = custoUnitarioTotal.textContent.replace('R$', '').trim().replace('.', '').replace(',', '.');
      const preco = precoVenda.textContent.replace('R$', '').trim().replace('.', '').replace(',', '.');
      const lucroUnit = lucroUnitario.textContent.replace('R$', '').trim().replace('.', '').replace(',', '.');
      const margem = detMargem.textContent.replace('%', '').replace(',', '.');
    
      // Adiciona ao histórico HTML
      const newRow = document.createElement('tr');
      newRow.innerHTML = `
        <td>${nome}</td>
        <td>${qtd}</td>
        <td>R$ ${parseFloat(custoUnit).toFixed(2).replace('.', ',')}</td>
        <td>R$ ${parseFloat(preco).toFixed(2).replace('.', ',')}</td>
        <td>R$ ${parseFloat(lucroUnit).toFixed(2).replace('.', ',')}</td>
        <td>${parseFloat(margem).toFixed(1).replace('.', ',')}%</td>
      `;
      historicoBody.insertBefore(newRow, historicoBody.firstChild);
    
      if (historicoBody.children.length > 10) {
        historicoBody.removeChild(historicoBody.lastChild);
      }
    
      // Salva no Supabase
      const { data, error } = await supabase
        .from('calculos')
        .insert([{
          nome_produto: nome,
          quantidade: parseInt(qtd),
          custo_unitario: parseFloat(custoUnit),
          preco_venda: parseFloat(preco),
          lucro_unitario: parseFloat(lucroUnit),
          margem: parseFloat(margem),
          created_at: new Date().toISOString(),
          user_id: user.id
        }]);
    
      if (error) throw error;
      
      btnSalvar.innerHTML = '<i class="fas fa-check"></i> Salvo com sucesso!';
      btnSalvar.classList.add('btn-success');
      setTimeout(() => {
        btnSalvar.innerHTML = '<i class="fas fa-save"></i> Salvar Cálculo';
        btnSalvar.classList.remove('btn-success');
      }, 2000);
      
    } catch (err) {
      console.error('Erro ao salvar cálculo:', err);
      mostrarToast('❌ Erro ao salvar o cálculo', 'error');
    }
  }

  async function limparHistorico() {
    try {
      const user = await getCurrentUser();
      
      const confirmacao = confirm('Tem certeza que deseja limpar todo o seu histórico de cálculos? Esta ação não pode ser desfeita.');
      
      if (!confirmacao) return;
      
      const { error } = await supabase
        .from('calculos')
        .delete()
        .eq('user_id', user.id);
      
      if (error) throw error;
      
      historicoBody.innerHTML = '';
      mostrarToast('✅ Histórico limpo com sucesso!');
      
    } catch (err) {
      console.error('Erro ao limpar histórico:', err);
      mostrarToast('❌ Erro ao limpar histórico', 'error');
    }
  }

  document.getElementById('btn-salvar-produto').addEventListener('click', async () => {
    const nome = document.getElementById('nome-produto').value.trim();
    const preco = parseFloat(precoVenda.textContent.replace('R$', '').replace(',', '.'));
    const custo = parseFloat(custoUnitarioTotal.textContent.replace('R$', '').replace(',', '.'));
    const quantidadeVal = parseInt(document.getElementById('quantidade').value);
    const despesasVal = parseFloat(despesasGerais.value);
  
    const user = await getCurrentUser();
  
    if (!nome || isNaN(preco) || isNaN(custo) || isNaN(quantidadeVal)) {
      mostrarToast('❌ Preencha e calcule corretamente antes de salvar', 'error');
      return;
    }
  
    // Verifica se já existe o produto
    const { data: produtoExistente, error: erroBusca } = await supabase
      .from('produtos')
      .select('*')
      .eq('user_id', user.id)
      .eq('nome', nome)
      .maybeSingle();
  
    if (produtoExistente) {
      mostrarToast('❌ Produto já cadastrado. Escolha outro nome.', 'error');
      return;
    }
  
    // Salvar no Supabase (tabela de produtos)
    await supabase.from('produtos').insert([{
      nome: nome,
      preco_unitario: preco,
      estoque: quantidadeVal,
      user_id: user.id
    }]);
  
    // Calcular ponto de equilíbrio corretamente (baseado só nos custos variáveis)
const custoMat = parseFloat(custoMaterial.value);
const maoObraVal = parseFloat(maoObra.value);

// custo variável por unidade = (matéria-prima + mão de obra) / quantidade
const custoVariavelUnitario = (custoMat + maoObraVal) / quantidadeVal;
const margemContribuicao = preco - custoVariavelUnitario;

const custoTotal = parseFloat(custoMaterial.value) + parseFloat(maoObra.value) + parseFloat(despesasGerais.value);
const pontoEquilibrio = preco > 0
  ? Math.ceil(custoTotal / preco)
  : 0;



    // Salvar no estoque
    const { error: estoqueError } = await supabase.from('Estoque').insert([{
      nome_produto: nome,
      preco: preco,
      custo_unitario: custo,
      despesas_fixas: despesasVal,
      estoque_atual: quantidadeVal,
      quantidade_vendida: 0,
      ponto_equilibrio: pontoEquilibrio,
      retorno_bruto: 0,
      user_id: user.id
    }]);
  
    if (estoqueError) {
      console.error('Erro ao inserir no estoque:', estoqueError);
      mostrarToast('❌ Erro ao salvar no estoque', 'error');
      return;
    }
  
    mostrarToast('✅ Produto salvo com sucesso!');
    carregarProdutosUsuario();
    carregarHistorico();
  });

  // Event listeners
  margemRange.addEventListener('input', function() {
    margemValue.textContent = this.value + '%';
  });

  form.addEventListener('submit', calcularPrecoVenda);
  btnSalvar.addEventListener('click', salvarCalculo);
  document.getElementById('limpar-historico').addEventListener('click', limparHistorico);

  // Inicialização
  carregarProdutosUsuario();
  carregarHistorico();
});
