// perfil.js
import { showToast } from './script.js';
import { getCurrentUser, getUserProfile, supabase } from './auth.js';

document.addEventListener('DOMContentLoaded', async () => {
  // Elementos do DOM
  const elements = {
    // Header
    userName: document.getElementById('user-name'),
    userEmail: document.getElementById('user-email'),
    userPlan: document.getElementById('user-plan'),
    
    // Formulário
    fullName: document.getElementById('full-name'),
    businessName: document.getElementById('business-name'),
    email: document.getElementById('perfil-email'),
    phone: document.getElementById('perfil-telefone'),
    bio: document.getElementById('bio'),
    
    // Botões
    editBtn: document.getElementById('edit-btn'),
    saveBtn: document.getElementById('save-btn'),
    cancelBtn: document.getElementById('cancel-btn'),
    
    // Modal
    confirmModal: document.getElementById('password-confirm-modal'),
    passwordForm: document.getElementById('password-confirm-form'),
    passwordInput: document.getElementById('confirm-password')
  };

  let originalData = {};
  let currentUser = null;

  // Carrega os dados do usuário
  async function loadUserData() {
    try {
      currentUser = await getCurrentUser();
      console.log("Usuário atual:", currentUser);
      if (!currentUser) {
        showToast('Usuário não autenticado', 'error');
        return;
      }

      // Carrega dados do perfil
      const profile = await getUserProfile(currentUser.id);
      console.log("Perfil:", profile);
      // Preenche os campos
      elements.userName.textContent = profile.nome || currentUser.email;
      elements.userEmail.textContent = currentUser.email;
      
      elements.fullName.value = profile.nome || '';
      elements.businessName.value = profile.negocio || '';
      elements.email.value = currentUser.email;
      elements.phone.value = profile.telefone || '';
      elements.bio.value = profile.bio || '';
      
      // Salva os dados originais para possível cancelamento
      originalData = {
        nome: profile.nome || '',
        negocio: profile.negocio || '',
        telefone: profile.telefone || '',
        bio: profile.bio || ''
      };

    } catch (error) {
      console.error('Erro ao carregar dados:', error);
      showToast('Erro ao carregar perfil', 'error');
    }
  }

  // Habilita/desabilita edição
  function toggleEditMode(enable) {
    [elements.fullName, elements.businessName, elements.phone, elements.bio].forEach(input => {
      input.disabled = !enable;
    });
    
    elements.editBtn.style.display = enable ? 'none' : 'block';
    elements.saveBtn.style.display = enable ? 'block' : 'none';
    elements.cancelBtn.style.display = enable ? 'block' : 'none';
  }

  // Event Listeners
  elements.editBtn.addEventListener('click', () => {
    toggleEditMode(true);
  });

  elements.cancelBtn.addEventListener('click', () => {
    // Restaura os valores originais
    elements.fullName.value = originalData.nome;
    elements.businessName.value = originalData.negocio;
    elements.phone.value = originalData.telefone;
    elements.bio.value = originalData.bio;
    
    toggleEditMode(false);
  });

  elements.saveBtn.addEventListener('click', () => {
    elements.confirmModal.classList.add('active');
    document.body.style.overflow = 'hidden';
  });

  // Fechar modal ao clicar fora ou no botão de fechar
  document.querySelectorAll('[data-modal-close]').forEach(btn => {
    btn.addEventListener('click', () => {
      elements.confirmModal.classList.remove('active');
      document.body.style.overflow = 'auto';
      elements.passwordInput.value = '';
    });
  });

  // Envio do formulário de confirmação de senha
  elements.passwordForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const password = elements.passwordInput.value;
    
    try {
      // Verifica a senha
      const { error } = await supabase.auth.signInWithPassword({
        email: currentUser.email,
        password: password
      });

      if (error) throw error;

      // Atualiza os dados do perfil
      const updates = {
        nome: elements.fullName.value.trim(),
        negocio: elements.businessName.value.trim(),
        telefone: elements.phone.value.trim(),
        bio: elements.bio.value.trim()
      };

      // Atualiza na tabela de usuários
      const { error: updateError } = await supabase
        .from('usuarios')
        .update(updates)
        .eq('id', currentUser.id);

      if (updateError) throw updateError;

      // Atualiza os metadados do auth
      await supabase.auth.updateUser({
        data: {
          nome: updates.nome,
          negocio: updates.negocio,
          telefone: updates.telefone
        }
      });

      // Atualiza a exibição
      elements.userName.textContent = updates.nome || currentUser.email;
      originalData = { ...updates };
      
      // Fecha o modal e desabilita edição
      elements.confirmModal.classList.remove('active');
      document.body.style.overflow = 'auto';
      elements.passwordInput.value = '';
      toggleEditMode(false);
      
      showToast('Perfil atualizado com sucesso!', 'success');
      
    } catch (error) {
      console.error('Erro ao atualizar perfil:', error);
      showToast('Senha incorreta ou erro ao atualizar', 'error');
      elements.passwordInput.value = '';
    }
  });

  // Toggle para mostrar/esconder senha
  document.querySelectorAll('.toggle-password').forEach(btn => {
    btn.addEventListener('click', function() {
      const input = this.previousElementSibling;
      const icon = this.querySelector('i');
      
      if (input.type === 'password') {
        input.type = 'text';
        icon.classList.replace('fa-eye', 'fa-eye-slash');
      } else {
        input.type = 'password';
        icon.classList.replace('fa-eye-slash', 'fa-eye');
      }
    });
  });

  // Inicialização
  await loadUserData();
  updateAuthUI();
  setupLogout();
});