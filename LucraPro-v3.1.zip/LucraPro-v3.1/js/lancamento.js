// Configuração do Supabase
const supabaseUrl = 'https://ygowfhgytljosfjcjnud.supabase.co';
const supabaseKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Inlnb3dmaGd5dGxqb3NmamNqbnVkIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDg3MDY4MDMsImV4cCI6MjA2NDI4MjgwM30.KA82uRfKzJS6y6X_lDjEef3IzmhubTGOsrp1QWEgaAk';
const supabase = window.supabase.createClient(supabaseUrl, supabaseKey);

// Função para verificar autenticação
async function checkAuth() {
  const { data: { user }, error } = await supabase.auth.getUser();
  if (error || !user) {
    window.location.href = 'index.html'; // Redireciona para index.html
    return null;
  }
  return user;
}

// Função para configurar logout
function setupLogout() {
  const logoutBtn = document.getElementById('logout-btn');
  if (logoutBtn) {
    logoutBtn.addEventListener('click', async () => {
      await supabase.auth.signOut();
      window.location.href = 'index.html'; // Redireciona para index.html
    });
  }
}

document.addEventListener('DOMContentLoaded', async () => {
  // Verifica autenticação
  const user = await checkAuth();
  if (!user) return;

  // Configura logout
  setupLogout();

  // Verificar se estamos na página de lançamento
  if (document.getElementById('form-lancamento')) {
    // Carregar dados iniciais
    await carregarProdutos(user.id);
    await carregarVendas(user.id);

    // Elementos do DOM
    const modalProduto = document.getElementById('modal-produto');
    const btnAbrirModal = document.getElementById('criar-novo-produto');
    const btnFecharModal = document.getElementById('fechar-modal');
    const formProduto = document.getElementById('form-produto');
    const formLancamento = document.getElementById('form-lancamento');

    // Abrir modal de produto
    btnAbrirModal.addEventListener('click', () => {
      modalProduto.style.display = 'flex';
      document.getElementById('nome-produto').focus();
    });

    // Fechar modal de produto
    btnFecharModal.addEventListener('click', () => {
      modalProduto.style.display = 'none';
    });

    // Fechar modal ao clicar fora
    modalProduto.addEventListener('click', (e) => {
      if (e.target === modalProduto) {
        modalProduto.style.display = 'none';
      }
    });

    // Formulário de produto
    formProduto.addEventListener('submit', async (e) => {
      e.preventDefault();
      
      // Pegar valores do formulário
      const nome = document.getElementById('nome-produto').value.trim();
      const preco = parseFloat(document.getElementById('preco-produto').value);
      const estoque = parseInt(document.getElementById('estoque-produto').value);

      // Validar campos
      if (!nome || isNaN(preco) || isNaN(estoque)) {
        mostrarNotificacao('Preencha todos os campos corretamente!', 'erro');
        return;
      }

      // Botão de submit
      const btnSubmit = formProduto.querySelector('button[type="submit"]');
      btnSubmit.disabled = true;
      btnSubmit.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Salvando...';

      try {
        // Inserir no Supabase
        const { data, error } = await supabase
          .from('produtos')
          .insert([{
            nome: nome,
            preco_unitario: preco,
            estoque: estoque,
            user_id: user.id
          }])
          .select();

          // Também insere na tabela Estoque
const { error: estoqueError } = await supabase
.from('Estoque')
.insert([{
  user_id: user.id,
  nome_produto: nome,
  estoque_atual: estoque,
  preco: preco,
  quantidade_vendida: 0,
  custo_unitario: preco * 0.6,  // Exemplo: custo como 60% do preço
  ponto_equilibrio: 0,
  retorno_bruto: 0
}]);

if (estoqueError) console.error('Erro ao criar produto no Estoque:', estoqueError);


        if (error) throw error;

        // Atualizar lista de produtos
        await carregarProdutos(user.id);
        
        // Selecionar o novo produto automaticamente
        document.getElementById('produto').value = nome;
        
        // Fechar modal e limpar formulário
        modalProduto.style.display = 'none';
        formProduto.reset();
        
        // Mostrar notificação
        mostrarNotificacao('Produto criado com sucesso!', 'sucesso');
        
      } catch (error) {
        console.error('Erro ao criar produto:', error);
        mostrarNotificacao('Erro ao criar produto: ' + error.message, 'erro');
      } finally {
        btnSubmit.disabled = false;
        btnSubmit.innerHTML = '<i class="fas fa-save"></i> Salvar Produto';
      }
    });

    // Formulário de lançamento
    formLancamento.addEventListener('submit', async (e) => {
      e.preventDefault();
      
      // Pegar valores do formulário
      const produto = document.getElementById('produto').value;
      const quantidade = parseInt(document.getElementById('quantidade-vendida').value);
      const preco = parseFloat(document.getElementById('preco-venda').value);

      // Validar campos
      if (!produto || isNaN(quantidade) || isNaN(preco)) {
        mostrarNotificacao('Preencha todos os campos corretamente!', 'erro');
        return;
      }

      const total = quantidade * preco;
      
      try {
        // Registrar venda
        const { error } = await supabase
          .from('vendas')
          .insert([{
            produto: produto,
            quantidade: quantidade,
            preco_unitario: preco,
            total: total,
            data_venda: new Date().toISOString(),
            user_id: user.id
          }]);

        if (error) throw error;

        // Atualizar estoque
        await atualizarEstoque(produto, quantidade, preco, user.id);

        
        // Mostrar notificação
        mostrarNotificacao('Venda registrada com sucesso!', 'sucesso');
        
        // Limpar formulário e atualizar histórico
        formLancamento.reset();
        await carregarVendas(user.id);

        mostrarNotificacao('Venda registrada com sucesso!', 'sucesso');


        
      } catch (error) {
        console.error('Erro ao registrar venda:', error);
        mostrarNotificacao('Erro ao registrar venda: ' + error.message, 'erro');
      }
    });
  }
});

// Função para carregar produtos
async function carregarProdutos(userId) {
  const selectProduto = document.getElementById('produto');
  
  // Verificar se o elemento existe
  if (!selectProduto) return;

  try {
    const { data: produtos, error } = await supabase
      .from('produtos')
      .select('nome, preco_unitario')
      .eq('user_id', userId)
      .order('nome', { ascending: true });

    if (error) throw error;

    // Limpar select
    selectProduto.innerHTML = '<option value="" disabled selected>Selecione um produto</option>';

    // Adicionar produtos ao select
    produtos.forEach(produto => {
      const option = document.createElement('option');
      option.value = produto.nome;
      option.textContent = produto.nome;
      option.dataset.preco = produto.preco_unitario;
      selectProduto.appendChild(option);
    });

    // Atualizar preço quando selecionar produto
    selectProduto.addEventListener('change', function() {
      const selectedOption = this.options[this.selectedIndex];
      if (selectedOption.dataset.preco) {
        const precoVenda = document.getElementById('preco-venda');
        if (precoVenda) {
          precoVenda.value = parseFloat(selectedOption.dataset.preco).toFixed(2);
        }
      }
    });

  } catch (error) {
    console.error('Erro ao carregar produtos:', error);
    mostrarNotificacao('Erro ao carregar produtos', 'erro');
  }
}

// Função para carregar vendas
async function carregarVendas(userId) {
  const tbody = document.getElementById('historico-vendas');
  
  // Verificar se o elemento existe
  if (!tbody) return;

  try {
    const { data: vendas, error } = await supabase
      .from('vendas')
      .select('*')
      .eq('user_id', userId)
      .order('data_venda', { ascending: false });

    if (error) throw error;

    tbody.innerHTML = '';

    // Adicionar vendas à tabela
    vendas.forEach(venda => {
      const tr = document.createElement('tr');
      tr.innerHTML = `
        <td>${venda.produto || 'N/A'}</td>
        <td>${venda.quantidade || 0}</td>
        <td>R$ ${(venda.preco_unitario || 0).toFixed(2)}</td>
        <td>R$ ${(venda.total || 0).toFixed(2)}</td>
      `;
      tbody.appendChild(tr);
    });

  } catch (error) {
    console.error('Erro ao carregar vendas:', error);
    mostrarNotificacao('Erro ao carregar histórico de vendas', 'erro');
  }
}

async function atualizarEstoque(nomeProduto, quantidadeVendida, precoVendaReal, userId) {
  try {
    // Atualizar tabela "produtos"
    const { data: produto, error } = await supabase
      .from('produtos')
      .select('estoque')
      .eq('nome', nomeProduto)
      .eq('user_id', userId)
      .single();

    if (error) throw error;

    const novoEstoque = produto.estoque - quantidadeVendida;

    const { error: updateError } = await supabase
      .from('produtos')
      .update({ estoque: novoEstoque })
      .eq('nome', nomeProduto)
      .eq('user_id', userId);

    if (updateError) throw updateError;

    // Atualizar tabela "Estoque"
    const { data: estoqueItem, error: estoqueFetchError } = await supabase
      .from('Estoque')
      .select('*')
      .eq('nome_produto', nomeProduto)
      .eq('user_id', userId)
      .single();

      if (!estoqueFetchError && estoqueItem) {
        const novoEstoque = estoqueItem.estoque_atual - quantidadeVendida;
        const novaQtdVendida = estoqueItem.quantidade_vendida + quantidadeVendida;
        const novoRetornoBruto = estoqueItem.retorno_bruto + (quantidadeVendida * precoVendaReal);
      
        const { error: updateEstoqueError } = await supabase
          .from('Estoque')
          .update({
            estoque_atual: novoEstoque,
            quantidade_vendida: novaQtdVendida,
            retorno_bruto: novoRetornoBruto
          })
          .eq('nome_produto', nomeProduto)
          .eq('user_id', userId);
      
        if (updateEstoqueError) {
          console.error('Erro ao atualizar Estoque:', updateEstoqueError);
        }
      }
      

  } catch (error) {
    console.error('Erro ao atualizar estoque:', error);
    throw error;
  }
}


// Função para mostrar notificações
function mostrarNotificacao(mensagem, tipo) {
  const notificacao = document.createElement('div');
  notificacao.className = `notificacao ${tipo}`;
  notificacao.innerHTML = `
    <i class="fas fa-${tipo === 'sucesso' ? 'check' : 'exclamation'}-circle"></i>
    ${mensagem}
  `;
  
  document.body.appendChild(notificacao);
  
  // Mostrar notificação
  setTimeout(() => {
    notificacao.classList.add('mostrar');
  }, 10);
  
  // Esconder e remover após 5 segundos
  setTimeout(() => {
    notificacao.classList.remove('mostrar');
    setTimeout(() => {
      document.body.removeChild(notificacao);
    }, 300);
  }, 5000);
}